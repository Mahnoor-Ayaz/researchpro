/**
 */
package research2;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Classifier</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research2.Classifier#getPrediction <em>Prediction</em>}</li>
 *   <li>{@link research2.Classifier#getName <em>Name</em>}</li>
 *   <li>{@link research2.Classifier#getDataset <em>Dataset</em>}</li>
 *   <li>{@link research2.Classifier#getFeatureextraction <em>Featureextraction</em>}</li>
 *   <li>{@link research2.Classifier#getModel <em>Model</em>}</li>
 * </ul>
 *
 * @see research2.Research2Package#getClassifier()
 * @model
 * @generated
 */
public interface Classifier extends EObject {
	/**
	 * Returns the value of the '<em><b>Prediction</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Prediction</em>' reference.
	 * @see #setPrediction(Prediction)
	 * @see research2.Research2Package#getClassifier_Prediction()
	 * @model
	 * @generated
	 */
	Prediction getPrediction();

	/**
	 * Sets the value of the '{@link research2.Classifier#getPrediction <em>Prediction</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Prediction</em>' reference.
	 * @see #getPrediction()
	 * @generated
	 */
	void setPrediction(Prediction value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see research2.Research2Package#getClassifier_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link research2.Classifier#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Dataset</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dataset</em>' attribute.
	 * @see #setDataset(String)
	 * @see research2.Research2Package#getClassifier_Dataset()
	 * @model
	 * @generated
	 */
	String getDataset();

	/**
	 * Sets the value of the '{@link research2.Classifier#getDataset <em>Dataset</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dataset</em>' attribute.
	 * @see #getDataset()
	 * @generated
	 */
	void setDataset(String value);

	/**
	 * Returns the value of the '<em><b>Featureextraction</b></em>' containment reference list.
	 * The list contents are of type {@link research2.FeatureExtraction}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Featureextraction</em>' containment reference list.
	 * @see research2.Research2Package#getClassifier_Featureextraction()
	 * @model containment="true"
	 * @generated
	 */
	EList<FeatureExtraction> getFeatureextraction();

	/**
	 * Returns the value of the '<em><b>Model</b></em>' containment reference list.
	 * The list contents are of type {@link research2.Model}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Model</em>' containment reference list.
	 * @see research2.Research2Package#getClassifier_Model()
	 * @model containment="true"
	 * @generated
	 */
	EList<Model> getModel();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void classify();

} // Classifier
