/**
 */
package research2;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>List</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research2.List#getGoesto <em>Goesto</em>}</li>
 *   <li>{@link research2.List#getTitle <em>Title</em>}</li>
 * </ul>
 *
 * @see research2.Research2Package#getList()
 * @model
 * @generated
 */
public interface List extends EObject {
	/**
	 * Returns the value of the '<em><b>Goesto</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Goesto</em>' reference.
	 * @see #setGoesto(Doctor)
	 * @see research2.Research2Package#getList_Goesto()
	 * @model
	 * @generated
	 */
	Doctor getGoesto();

	/**
	 * Sets the value of the '{@link research2.List#getGoesto <em>Goesto</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Goesto</em>' reference.
	 * @see #getGoesto()
	 * @generated
	 */
	void setGoesto(Doctor value);

	/**
	 * Returns the value of the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Title</em>' attribute.
	 * @see #setTitle(String)
	 * @see research2.Research2Package#getList_Title()
	 * @model
	 * @generated
	 */
	String getTitle();

	/**
	 * Sets the value of the '{@link research2.List#getTitle <em>Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Title</em>' attribute.
	 * @see #getTitle()
	 * @generated
	 */
	void setTitle(String value);

} // List
