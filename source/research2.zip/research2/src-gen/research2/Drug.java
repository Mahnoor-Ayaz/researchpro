/**
 */
package research2;

import java.util.Date;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Drug</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research2.Drug#getOfdiesease <em>Ofdiesease</em>}</li>
 *   <li>{@link research2.Drug#getType <em>Type</em>}</li>
 *   <li>{@link research2.Drug#getName <em>Name</em>}</li>
 *   <li>{@link research2.Drug#getPrice <em>Price</em>}</li>
 *   <li>{@link research2.Drug#getManufactoringDate <em>Manufactoring Date</em>}</li>
 *   <li>{@link research2.Drug#getExpiryDate <em>Expiry Date</em>}</li>
 * </ul>
 *
 * @see research2.Research2Package#getDrug()
 * @model
 * @generated
 */
public interface Drug extends EObject {
	/**
	 * Returns the value of the '<em><b>Ofdiesease</b></em>' reference list.
	 * The list contents are of type {@link research2.Diesease}.
	 * It is bidirectional and its opposite is '{@link research2.Diesease#getOfdrug <em>Ofdrug</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ofdiesease</em>' reference list.
	 * @see research2.Research2Package#getDrug_Ofdiesease()
	 * @see research2.Diesease#getOfdrug
	 * @model opposite="ofdrug" required="true"
	 * @generated
	 */
	EList<Diesease> getOfdiesease();

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link research2.DrugType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see research2.DrugType
	 * @see #setType(DrugType)
	 * @see research2.Research2Package#getDrug_Type()
	 * @model
	 * @generated
	 */
	DrugType getType();

	/**
	 * Sets the value of the '{@link research2.Drug#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see research2.DrugType
	 * @see #getType()
	 * @generated
	 */
	void setType(DrugType value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see research2.Research2Package#getDrug_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link research2.Drug#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Price</em>' attribute.
	 * @see #setPrice(int)
	 * @see research2.Research2Package#getDrug_Price()
	 * @model
	 * @generated
	 */
	int getPrice();

	/**
	 * Sets the value of the '{@link research2.Drug#getPrice <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Price</em>' attribute.
	 * @see #getPrice()
	 * @generated
	 */
	void setPrice(int value);

	/**
	 * Returns the value of the '<em><b>Manufactoring Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Manufactoring Date</em>' attribute.
	 * @see #setManufactoringDate(Date)
	 * @see research2.Research2Package#getDrug_ManufactoringDate()
	 * @model
	 * @generated
	 */
	Date getManufactoringDate();

	/**
	 * Sets the value of the '{@link research2.Drug#getManufactoringDate <em>Manufactoring Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Manufactoring Date</em>' attribute.
	 * @see #getManufactoringDate()
	 * @generated
	 */
	void setManufactoringDate(Date value);

	/**
	 * Returns the value of the '<em><b>Expiry Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Expiry Date</em>' attribute.
	 * @see #setExpiryDate(Date)
	 * @see research2.Research2Package#getDrug_ExpiryDate()
	 * @model
	 * @generated
	 */
	Date getExpiryDate();

	/**
	 * Sets the value of the '{@link research2.Drug#getExpiryDate <em>Expiry Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Expiry Date</em>' attribute.
	 * @see #getExpiryDate()
	 * @generated
	 */
	void setExpiryDate(Date value);

} // Drug
