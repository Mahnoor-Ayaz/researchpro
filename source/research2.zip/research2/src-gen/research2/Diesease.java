/**
 */
package research2;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Diesease</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research2.Diesease#getOfdrug <em>Ofdrug</em>}</li>
 *   <li>{@link research2.Diesease#getName <em>Name</em>}</li>
 *   <li>{@link research2.Diesease#getSeverity <em>Severity</em>}</li>
 * </ul>
 *
 * @see research2.Research2Package#getDiesease()
 * @model
 * @generated
 */
public interface Diesease extends EObject {
	/**
	 * Returns the value of the '<em><b>Ofdrug</b></em>' reference list.
	 * The list contents are of type {@link research2.Drug}.
	 * It is bidirectional and its opposite is '{@link research2.Drug#getOfdiesease <em>Ofdiesease</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ofdrug</em>' reference list.
	 * @see research2.Research2Package#getDiesease_Ofdrug()
	 * @see research2.Drug#getOfdiesease
	 * @model opposite="ofdiesease"
	 * @generated
	 */
	EList<Drug> getOfdrug();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see research2.Research2Package#getDiesease_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link research2.Diesease#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Severity</b></em>' attribute.
	 * The literals are from the enumeration {@link research2.Severity}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Severity</em>' attribute.
	 * @see research2.Severity
	 * @see #setSeverity(Severity)
	 * @see research2.Research2Package#getDiesease_Severity()
	 * @model
	 * @generated
	 */
	Severity getSeverity();

	/**
	 * Sets the value of the '{@link research2.Diesease#getSeverity <em>Severity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Severity</em>' attribute.
	 * @see research2.Severity
	 * @see #getSeverity()
	 * @generated
	 */
	void setSeverity(Severity value);

} // Diesease
