/**
 */
package research2;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Recommendation System</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research2.RecommendationSystem#getClassifier <em>Classifier</em>}</li>
 *   <li>{@link research2.RecommendationSystem#getTitle <em>Title</em>}</li>
 *   <li>{@link research2.RecommendationSystem#getList <em>List</em>}</li>
 * </ul>
 *
 * @see research2.Research2Package#getRecommendationSystem()
 * @model
 * @generated
 */
public interface RecommendationSystem extends EObject {
	/**
	 * Returns the value of the '<em><b>Classifier</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Classifier</em>' reference.
	 * @see #setClassifier(Classifier)
	 * @see research2.Research2Package#getRecommendationSystem_Classifier()
	 * @model
	 * @generated
	 */
	Classifier getClassifier();

	/**
	 * Sets the value of the '{@link research2.RecommendationSystem#getClassifier <em>Classifier</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Classifier</em>' reference.
	 * @see #getClassifier()
	 * @generated
	 */
	void setClassifier(Classifier value);

	/**
	 * Returns the value of the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Title</em>' attribute.
	 * @see #setTitle(String)
	 * @see research2.Research2Package#getRecommendationSystem_Title()
	 * @model
	 * @generated
	 */
	String getTitle();

	/**
	 * Sets the value of the '{@link research2.RecommendationSystem#getTitle <em>Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Title</em>' attribute.
	 * @see #getTitle()
	 * @generated
	 */
	void setTitle(String value);

	/**
	 * Returns the value of the '<em><b>List</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>List</em>' reference.
	 * @see #setList(List)
	 * @see research2.Research2Package#getRecommendationSystem_List()
	 * @model
	 * @generated
	 */
	List getList();

	/**
	 * Sets the value of the '{@link research2.RecommendationSystem#getList <em>List</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>List</em>' reference.
	 * @see #getList()
	 * @generated
	 */
	void setList(List value);

} // RecommendationSystem
