/**
 */
package research2;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Patient</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research2.Patient#getHistory <em>History</em>}</li>
 *   <li>{@link research2.Patient#getGetprescription <em>Getprescription</em>}</li>
 *   <li>{@link research2.Patient#getHavedoctor <em>Havedoctor</em>}</li>
 *   <li>{@link research2.Patient#getName <em>Name</em>}</li>
 *   <li>{@link research2.Patient#getPatientId <em>Patient Id</em>}</li>
 *   <li>{@link research2.Patient#getAge <em>Age</em>}</li>
 * </ul>
 *
 * @see research2.Research2Package#getPatient()
 * @model
 * @generated
 */
public interface Patient extends EObject {
	/**
	 * Returns the value of the '<em><b>History</b></em>' reference list.
	 * The list contents are of type {@link research2.History}.
	 * It is bidirectional and its opposite is '{@link research2.History#getPatient <em>Patient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>History</em>' reference list.
	 * @see research2.Research2Package#getPatient_History()
	 * @see research2.History#getPatient
	 * @model opposite="patient"
	 * @generated
	 */
	EList<History> getHistory();

	/**
	 * Returns the value of the '<em><b>Getprescription</b></em>' reference list.
	 * The list contents are of type {@link research2.Prescription}.
	 * It is bidirectional and its opposite is '{@link research2.Prescription#getPatient <em>Patient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Getprescription</em>' reference list.
	 * @see research2.Research2Package#getPatient_Getprescription()
	 * @see research2.Prescription#getPatient
	 * @model opposite="patient"
	 * @generated
	 */
	EList<Prescription> getGetprescription();

	/**
	 * Returns the value of the '<em><b>Havedoctor</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link research2.Doctor#getHavepatient <em>Havepatient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Havedoctor</em>' reference.
	 * @see #setHavedoctor(Doctor)
	 * @see research2.Research2Package#getPatient_Havedoctor()
	 * @see research2.Doctor#getHavepatient
	 * @model opposite="havepatient" required="true"
	 * @generated
	 */
	Doctor getHavedoctor();

	/**
	 * Sets the value of the '{@link research2.Patient#getHavedoctor <em>Havedoctor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Havedoctor</em>' reference.
	 * @see #getHavedoctor()
	 * @generated
	 */
	void setHavedoctor(Doctor value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see research2.Research2Package#getPatient_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link research2.Patient#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Patient Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Patient Id</em>' attribute.
	 * @see #setPatientId(String)
	 * @see research2.Research2Package#getPatient_PatientId()
	 * @model
	 * @generated
	 */
	String getPatientId();

	/**
	 * Sets the value of the '{@link research2.Patient#getPatientId <em>Patient Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Patient Id</em>' attribute.
	 * @see #getPatientId()
	 * @generated
	 */
	void setPatientId(String value);

	/**
	 * Returns the value of the '<em><b>Age</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Age</em>' attribute.
	 * @see #setAge(int)
	 * @see research2.Research2Package#getPatient_Age()
	 * @model
	 * @generated
	 */
	int getAge();

	/**
	 * Sets the value of the '{@link research2.Patient#getAge <em>Age</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Age</em>' attribute.
	 * @see #getAge()
	 * @generated
	 */
	void setAge(int value);

} // Patient
