/**
 */
package research2;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pharmacist</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research2.Pharmacist#getGet <em>Get</em>}</li>
 *   <li>{@link research2.Pharmacist#getCheckstock <em>Checkstock</em>}</li>
 *   <li>{@link research2.Pharmacist#getName <em>Name</em>}</li>
 *   <li>{@link research2.Pharmacist#getPharmacitId <em>Pharmacit Id</em>}</li>
 * </ul>
 *
 * @see research2.Research2Package#getPharmacist()
 * @model
 * @generated
 */
public interface Pharmacist extends EObject {
	/**
	 * Returns the value of the '<em><b>Get</b></em>' reference list.
	 * The list contents are of type {@link research2.Prescription}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Get</em>' reference list.
	 * @see research2.Research2Package#getPharmacist_Get()
	 * @model
	 * @generated
	 */
	EList<Prescription> getGet();

	/**
	 * Returns the value of the '<em><b>Checkstock</b></em>' reference list.
	 * The list contents are of type {@link research2.Stock}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Checkstock</em>' reference list.
	 * @see research2.Research2Package#getPharmacist_Checkstock()
	 * @model
	 * @generated
	 */
	EList<Stock> getCheckstock();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see research2.Research2Package#getPharmacist_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link research2.Pharmacist#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Pharmacit Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pharmacit Id</em>' attribute.
	 * @see #setPharmacitId(int)
	 * @see research2.Research2Package#getPharmacist_PharmacitId()
	 * @model
	 * @generated
	 */
	int getPharmacitId();

	/**
	 * Sets the value of the '{@link research2.Pharmacist#getPharmacitId <em>Pharmacit Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pharmacit Id</em>' attribute.
	 * @see #getPharmacitId()
	 * @generated
	 */
	void setPharmacitId(int value);

} // Pharmacist
