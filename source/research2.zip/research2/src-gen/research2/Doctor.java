/**
 */
package research2;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Doctor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research2.Doctor#getHavepatient <em>Havepatient</em>}</li>
 *   <li>{@link research2.Doctor#getDprescription <em>Dprescription</em>}</li>
 *   <li>{@link research2.Doctor#getName <em>Name</em>}</li>
 *   <li>{@link research2.Doctor#getDoctorId <em>Doctor Id</em>}</li>
 * </ul>
 *
 * @see research2.Research2Package#getDoctor()
 * @model
 * @generated
 */
public interface Doctor extends EObject {
	/**
	 * Returns the value of the '<em><b>Havepatient</b></em>' reference list.
	 * The list contents are of type {@link research2.Patient}.
	 * It is bidirectional and its opposite is '{@link research2.Patient#getHavedoctor <em>Havedoctor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Havepatient</em>' reference list.
	 * @see research2.Research2Package#getDoctor_Havepatient()
	 * @see research2.Patient#getHavedoctor
	 * @model opposite="havedoctor"
	 * @generated
	 */
	EList<Patient> getHavepatient();

	/**
	 * Returns the value of the '<em><b>Dprescription</b></em>' reference list.
	 * The list contents are of type {@link research2.Prescription}.
	 * It is bidirectional and its opposite is '{@link research2.Prescription#getPdoctor <em>Pdoctor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dprescription</em>' reference list.
	 * @see research2.Research2Package#getDoctor_Dprescription()
	 * @see research2.Prescription#getPdoctor
	 * @model opposite="pdoctor"
	 * @generated
	 */
	EList<Prescription> getDprescription();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see research2.Research2Package#getDoctor_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link research2.Doctor#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Doctor Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Doctor Id</em>' attribute.
	 * @see #setDoctorId(int)
	 * @see research2.Research2Package#getDoctor_DoctorId()
	 * @model
	 * @generated
	 */
	int getDoctorId();

	/**
	 * Sets the value of the '{@link research2.Doctor#getDoctorId <em>Doctor Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Doctor Id</em>' attribute.
	 * @see #getDoctorId()
	 * @generated
	 */
	void setDoctorId(int value);

} // Doctor
