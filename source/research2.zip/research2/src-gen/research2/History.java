/**
 */
package research2;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>History</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research2.History#getPatient <em>Patient</em>}</li>
 *   <li>{@link research2.History#getContaindiesease <em>Containdiesease</em>}</li>
 *   <li>{@link research2.History#getContaindrug <em>Containdrug</em>}</li>
 *   <li>{@link research2.History#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see research2.Research2Package#getHistory()
 * @model
 * @generated
 */
public interface History extends EObject {
	/**
	 * Returns the value of the '<em><b>Patient</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link research2.Patient#getHistory <em>History</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Patient</em>' reference.
	 * @see #setPatient(Patient)
	 * @see research2.Research2Package#getHistory_Patient()
	 * @see research2.Patient#getHistory
	 * @model opposite="history" required="true"
	 * @generated
	 */
	Patient getPatient();

	/**
	 * Sets the value of the '{@link research2.History#getPatient <em>Patient</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Patient</em>' reference.
	 * @see #getPatient()
	 * @generated
	 */
	void setPatient(Patient value);

	/**
	 * Returns the value of the '<em><b>Containdiesease</b></em>' reference list.
	 * The list contents are of type {@link research2.Diesease}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Containdiesease</em>' reference list.
	 * @see research2.Research2Package#getHistory_Containdiesease()
	 * @model required="true"
	 * @generated
	 */
	EList<Diesease> getContaindiesease();

	/**
	 * Returns the value of the '<em><b>Containdrug</b></em>' reference list.
	 * The list contents are of type {@link research2.Drug}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Containdrug</em>' reference list.
	 * @see research2.Research2Package#getHistory_Containdrug()
	 * @model required="true"
	 * @generated
	 */
	EList<Drug> getContaindrug();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see research2.Research2Package#getHistory_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link research2.History#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void view();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void modify();

} // History
