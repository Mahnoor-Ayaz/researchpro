/**
 */
package research2;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Prescription</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research2.Prescription#getHavedrug <em>Havedrug</em>}</li>
 *   <li>{@link research2.Prescription#getPatient <em>Patient</em>}</li>
 *   <li>{@link research2.Prescription#getPdoctor <em>Pdoctor</em>}</li>
 *   <li>{@link research2.Prescription#getQuantity <em>Quantity</em>}</li>
 *   <li>{@link research2.Prescription#getPrescriptionId <em>Prescription Id</em>}</li>
 *   <li>{@link research2.Prescription#getDrugname <em>Drugname</em>}</li>
 * </ul>
 *
 * @see research2.Research2Package#getPrescription()
 * @model
 * @generated
 */
public interface Prescription extends EObject {
	/**
	 * Returns the value of the '<em><b>Havedrug</b></em>' reference list.
	 * The list contents are of type {@link research2.Drug}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Havedrug</em>' reference list.
	 * @see research2.Research2Package#getPrescription_Havedrug()
	 * @model
	 * @generated
	 */
	EList<Drug> getHavedrug();

	/**
	 * Returns the value of the '<em><b>Patient</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link research2.Patient#getGetprescription <em>Getprescription</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Patient</em>' reference.
	 * @see #setPatient(Patient)
	 * @see research2.Research2Package#getPrescription_Patient()
	 * @see research2.Patient#getGetprescription
	 * @model opposite="getprescription" required="true"
	 * @generated
	 */
	Patient getPatient();

	/**
	 * Sets the value of the '{@link research2.Prescription#getPatient <em>Patient</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Patient</em>' reference.
	 * @see #getPatient()
	 * @generated
	 */
	void setPatient(Patient value);

	/**
	 * Returns the value of the '<em><b>Pdoctor</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link research2.Doctor#getDprescription <em>Dprescription</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pdoctor</em>' reference.
	 * @see #setPdoctor(Doctor)
	 * @see research2.Research2Package#getPrescription_Pdoctor()
	 * @see research2.Doctor#getDprescription
	 * @model opposite="dprescription" required="true"
	 * @generated
	 */
	Doctor getPdoctor();

	/**
	 * Sets the value of the '{@link research2.Prescription#getPdoctor <em>Pdoctor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pdoctor</em>' reference.
	 * @see #getPdoctor()
	 * @generated
	 */
	void setPdoctor(Doctor value);

	/**
	 * Returns the value of the '<em><b>Quantity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Quantity</em>' attribute.
	 * @see #setQuantity(int)
	 * @see research2.Research2Package#getPrescription_Quantity()
	 * @model
	 * @generated
	 */
	int getQuantity();

	/**
	 * Sets the value of the '{@link research2.Prescription#getQuantity <em>Quantity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Quantity</em>' attribute.
	 * @see #getQuantity()
	 * @generated
	 */
	void setQuantity(int value);

	/**
	 * Returns the value of the '<em><b>Prescription Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Prescription Id</em>' attribute.
	 * @see #setPrescriptionId(int)
	 * @see research2.Research2Package#getPrescription_PrescriptionId()
	 * @model
	 * @generated
	 */
	int getPrescriptionId();

	/**
	 * Sets the value of the '{@link research2.Prescription#getPrescriptionId <em>Prescription Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Prescription Id</em>' attribute.
	 * @see #getPrescriptionId()
	 * @generated
	 */
	void setPrescriptionId(int value);

	/**
	 * Returns the value of the '<em><b>Drugname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Drugname</em>' attribute.
	 * @see #setDrugname(String)
	 * @see research2.Research2Package#getPrescription_Drugname()
	 * @model
	 * @generated
	 */
	String getDrugname();

	/**
	 * Sets the value of the '{@link research2.Prescription#getDrugname <em>Drugname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Drugname</em>' attribute.
	 * @see #getDrugname()
	 * @generated
	 */
	void setDrugname(String value);

} // Prescription
