/**
 */
package research2;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Stock</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research2.Stock#getDrugs <em>Drugs</em>}</li>
 * </ul>
 *
 * @see research2.Research2Package#getStock()
 * @model
 * @generated
 */
public interface Stock extends EObject {
	/**
	 * Returns the value of the '<em><b>Drugs</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Drugs</em>' attribute.
	 * @see #setDrugs(String)
	 * @see research2.Research2Package#getStock_Drugs()
	 * @model
	 * @generated
	 */
	String getDrugs();

	/**
	 * Sets the value of the '{@link research2.Stock#getDrugs <em>Drugs</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Drugs</em>' attribute.
	 * @see #getDrugs()
	 * @generated
	 */
	void setDrugs(String value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void checkavailability();

} // Stock
