/**
 */
package research2.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import research2.Classifier;
import research2.Diesease;
import research2.Doctor;
import research2.Drug;
import research2.EPrescription;
import research2.History;
import research2.List;
import research2.Patient;
import research2.Pharmacist;
import research2.Prediction;
import research2.Prescription;
import research2.RecommendationSystem;
import research2.Research2Package;
import research2.Stock;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>EPrescription</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link research2.impl.EPrescriptionImpl#getPatient <em>Patient</em>}</li>
 *   <li>{@link research2.impl.EPrescriptionImpl#getDoctor <em>Doctor</em>}</li>
 *   <li>{@link research2.impl.EPrescriptionImpl#getPrescription <em>Prescription</em>}</li>
 *   <li>{@link research2.impl.EPrescriptionImpl#getHistory <em>History</em>}</li>
 *   <li>{@link research2.impl.EPrescriptionImpl#getRecommendationsystem <em>Recommendationsystem</em>}</li>
 *   <li>{@link research2.impl.EPrescriptionImpl#getPharmacist <em>Pharmacist</em>}</li>
 *   <li>{@link research2.impl.EPrescriptionImpl#getStock <em>Stock</em>}</li>
 *   <li>{@link research2.impl.EPrescriptionImpl#getClassifier <em>Classifier</em>}</li>
 *   <li>{@link research2.impl.EPrescriptionImpl#getPrediction <em>Prediction</em>}</li>
 *   <li>{@link research2.impl.EPrescriptionImpl#getList <em>List</em>}</li>
 *   <li>{@link research2.impl.EPrescriptionImpl#getDiesease <em>Diesease</em>}</li>
 *   <li>{@link research2.impl.EPrescriptionImpl#getDrug <em>Drug</em>}</li>
 * </ul>
 *
 * @generated
 */
public class EPrescriptionImpl extends MinimalEObjectImpl.Container implements EPrescription {
	/**
	 * The cached value of the '{@link #getPatient() <em>Patient</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPatient()
	 * @generated
	 * @ordered
	 */
	protected EList<Patient> patient;

	/**
	 * The cached value of the '{@link #getDoctor() <em>Doctor</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoctor()
	 * @generated
	 * @ordered
	 */
	protected EList<Doctor> doctor;

	/**
	 * The cached value of the '{@link #getPrescription() <em>Prescription</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrescription()
	 * @generated
	 * @ordered
	 */
	protected EList<Prescription> prescription;

	/**
	 * The cached value of the '{@link #getHistory() <em>History</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHistory()
	 * @generated
	 * @ordered
	 */
	protected EList<History> history;

	/**
	 * The cached value of the '{@link #getRecommendationsystem() <em>Recommendationsystem</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecommendationsystem()
	 * @generated
	 * @ordered
	 */
	protected EList<RecommendationSystem> recommendationsystem;

	/**
	 * The cached value of the '{@link #getPharmacist() <em>Pharmacist</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPharmacist()
	 * @generated
	 * @ordered
	 */
	protected EList<Pharmacist> pharmacist;

	/**
	 * The cached value of the '{@link #getStock() <em>Stock</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStock()
	 * @generated
	 * @ordered
	 */
	protected EList<Stock> stock;

	/**
	 * The cached value of the '{@link #getClassifier() <em>Classifier</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClassifier()
	 * @generated
	 * @ordered
	 */
	protected EList<Classifier> classifier;

	/**
	 * The cached value of the '{@link #getPrediction() <em>Prediction</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrediction()
	 * @generated
	 * @ordered
	 */
	protected EList<Prediction> prediction;

	/**
	 * The cached value of the '{@link #getList() <em>List</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getList()
	 * @generated
	 * @ordered
	 */
	protected EList<List> list;

	/**
	 * The cached value of the '{@link #getDiesease() <em>Diesease</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDiesease()
	 * @generated
	 * @ordered
	 */
	protected EList<Diesease> diesease;

	/**
	 * The cached value of the '{@link #getDrug() <em>Drug</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDrug()
	 * @generated
	 * @ordered
	 */
	protected EList<Drug> drug;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EPrescriptionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Research2Package.Literals.EPRESCRIPTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Patient> getPatient() {
		if (patient == null) {
			patient = new EObjectContainmentEList<Patient>(Patient.class, this,
					Research2Package.EPRESCRIPTION__PATIENT);
		}
		return patient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Doctor> getDoctor() {
		if (doctor == null) {
			doctor = new EObjectContainmentEList<Doctor>(Doctor.class, this, Research2Package.EPRESCRIPTION__DOCTOR);
		}
		return doctor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Prescription> getPrescription() {
		if (prescription == null) {
			prescription = new EObjectContainmentEList<Prescription>(Prescription.class, this,
					Research2Package.EPRESCRIPTION__PRESCRIPTION);
		}
		return prescription;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<History> getHistory() {
		if (history == null) {
			history = new EObjectContainmentEList<History>(History.class, this,
					Research2Package.EPRESCRIPTION__HISTORY);
		}
		return history;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RecommendationSystem> getRecommendationsystem() {
		if (recommendationsystem == null) {
			recommendationsystem = new EObjectContainmentEList<RecommendationSystem>(RecommendationSystem.class, this,
					Research2Package.EPRESCRIPTION__RECOMMENDATIONSYSTEM);
		}
		return recommendationsystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Pharmacist> getPharmacist() {
		if (pharmacist == null) {
			pharmacist = new EObjectContainmentEList<Pharmacist>(Pharmacist.class, this,
					Research2Package.EPRESCRIPTION__PHARMACIST);
		}
		return pharmacist;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Stock> getStock() {
		if (stock == null) {
			stock = new EObjectContainmentEList<Stock>(Stock.class, this, Research2Package.EPRESCRIPTION__STOCK);
		}
		return stock;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Classifier> getClassifier() {
		if (classifier == null) {
			classifier = new EObjectContainmentEList<Classifier>(Classifier.class, this,
					Research2Package.EPRESCRIPTION__CLASSIFIER);
		}
		return classifier;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Prediction> getPrediction() {
		if (prediction == null) {
			prediction = new EObjectContainmentEList<Prediction>(Prediction.class, this,
					Research2Package.EPRESCRIPTION__PREDICTION);
		}
		return prediction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<List> getList() {
		if (list == null) {
			list = new EObjectContainmentEList<List>(List.class, this, Research2Package.EPRESCRIPTION__LIST);
		}
		return list;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Diesease> getDiesease() {
		if (diesease == null) {
			diesease = new EObjectContainmentEList<Diesease>(Diesease.class, this,
					Research2Package.EPRESCRIPTION__DIESEASE);
		}
		return diesease;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Drug> getDrug() {
		if (drug == null) {
			drug = new EObjectContainmentEList<Drug>(Drug.class, this, Research2Package.EPRESCRIPTION__DRUG);
		}
		return drug;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Research2Package.EPRESCRIPTION__PATIENT:
			return ((InternalEList<?>) getPatient()).basicRemove(otherEnd, msgs);
		case Research2Package.EPRESCRIPTION__DOCTOR:
			return ((InternalEList<?>) getDoctor()).basicRemove(otherEnd, msgs);
		case Research2Package.EPRESCRIPTION__PRESCRIPTION:
			return ((InternalEList<?>) getPrescription()).basicRemove(otherEnd, msgs);
		case Research2Package.EPRESCRIPTION__HISTORY:
			return ((InternalEList<?>) getHistory()).basicRemove(otherEnd, msgs);
		case Research2Package.EPRESCRIPTION__RECOMMENDATIONSYSTEM:
			return ((InternalEList<?>) getRecommendationsystem()).basicRemove(otherEnd, msgs);
		case Research2Package.EPRESCRIPTION__PHARMACIST:
			return ((InternalEList<?>) getPharmacist()).basicRemove(otherEnd, msgs);
		case Research2Package.EPRESCRIPTION__STOCK:
			return ((InternalEList<?>) getStock()).basicRemove(otherEnd, msgs);
		case Research2Package.EPRESCRIPTION__CLASSIFIER:
			return ((InternalEList<?>) getClassifier()).basicRemove(otherEnd, msgs);
		case Research2Package.EPRESCRIPTION__PREDICTION:
			return ((InternalEList<?>) getPrediction()).basicRemove(otherEnd, msgs);
		case Research2Package.EPRESCRIPTION__LIST:
			return ((InternalEList<?>) getList()).basicRemove(otherEnd, msgs);
		case Research2Package.EPRESCRIPTION__DIESEASE:
			return ((InternalEList<?>) getDiesease()).basicRemove(otherEnd, msgs);
		case Research2Package.EPRESCRIPTION__DRUG:
			return ((InternalEList<?>) getDrug()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Research2Package.EPRESCRIPTION__PATIENT:
			return getPatient();
		case Research2Package.EPRESCRIPTION__DOCTOR:
			return getDoctor();
		case Research2Package.EPRESCRIPTION__PRESCRIPTION:
			return getPrescription();
		case Research2Package.EPRESCRIPTION__HISTORY:
			return getHistory();
		case Research2Package.EPRESCRIPTION__RECOMMENDATIONSYSTEM:
			return getRecommendationsystem();
		case Research2Package.EPRESCRIPTION__PHARMACIST:
			return getPharmacist();
		case Research2Package.EPRESCRIPTION__STOCK:
			return getStock();
		case Research2Package.EPRESCRIPTION__CLASSIFIER:
			return getClassifier();
		case Research2Package.EPRESCRIPTION__PREDICTION:
			return getPrediction();
		case Research2Package.EPRESCRIPTION__LIST:
			return getList();
		case Research2Package.EPRESCRIPTION__DIESEASE:
			return getDiesease();
		case Research2Package.EPRESCRIPTION__DRUG:
			return getDrug();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Research2Package.EPRESCRIPTION__PATIENT:
			getPatient().clear();
			getPatient().addAll((Collection<? extends Patient>) newValue);
			return;
		case Research2Package.EPRESCRIPTION__DOCTOR:
			getDoctor().clear();
			getDoctor().addAll((Collection<? extends Doctor>) newValue);
			return;
		case Research2Package.EPRESCRIPTION__PRESCRIPTION:
			getPrescription().clear();
			getPrescription().addAll((Collection<? extends Prescription>) newValue);
			return;
		case Research2Package.EPRESCRIPTION__HISTORY:
			getHistory().clear();
			getHistory().addAll((Collection<? extends History>) newValue);
			return;
		case Research2Package.EPRESCRIPTION__RECOMMENDATIONSYSTEM:
			getRecommendationsystem().clear();
			getRecommendationsystem().addAll((Collection<? extends RecommendationSystem>) newValue);
			return;
		case Research2Package.EPRESCRIPTION__PHARMACIST:
			getPharmacist().clear();
			getPharmacist().addAll((Collection<? extends Pharmacist>) newValue);
			return;
		case Research2Package.EPRESCRIPTION__STOCK:
			getStock().clear();
			getStock().addAll((Collection<? extends Stock>) newValue);
			return;
		case Research2Package.EPRESCRIPTION__CLASSIFIER:
			getClassifier().clear();
			getClassifier().addAll((Collection<? extends Classifier>) newValue);
			return;
		case Research2Package.EPRESCRIPTION__PREDICTION:
			getPrediction().clear();
			getPrediction().addAll((Collection<? extends Prediction>) newValue);
			return;
		case Research2Package.EPRESCRIPTION__LIST:
			getList().clear();
			getList().addAll((Collection<? extends List>) newValue);
			return;
		case Research2Package.EPRESCRIPTION__DIESEASE:
			getDiesease().clear();
			getDiesease().addAll((Collection<? extends Diesease>) newValue);
			return;
		case Research2Package.EPRESCRIPTION__DRUG:
			getDrug().clear();
			getDrug().addAll((Collection<? extends Drug>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Research2Package.EPRESCRIPTION__PATIENT:
			getPatient().clear();
			return;
		case Research2Package.EPRESCRIPTION__DOCTOR:
			getDoctor().clear();
			return;
		case Research2Package.EPRESCRIPTION__PRESCRIPTION:
			getPrescription().clear();
			return;
		case Research2Package.EPRESCRIPTION__HISTORY:
			getHistory().clear();
			return;
		case Research2Package.EPRESCRIPTION__RECOMMENDATIONSYSTEM:
			getRecommendationsystem().clear();
			return;
		case Research2Package.EPRESCRIPTION__PHARMACIST:
			getPharmacist().clear();
			return;
		case Research2Package.EPRESCRIPTION__STOCK:
			getStock().clear();
			return;
		case Research2Package.EPRESCRIPTION__CLASSIFIER:
			getClassifier().clear();
			return;
		case Research2Package.EPRESCRIPTION__PREDICTION:
			getPrediction().clear();
			return;
		case Research2Package.EPRESCRIPTION__LIST:
			getList().clear();
			return;
		case Research2Package.EPRESCRIPTION__DIESEASE:
			getDiesease().clear();
			return;
		case Research2Package.EPRESCRIPTION__DRUG:
			getDrug().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Research2Package.EPRESCRIPTION__PATIENT:
			return patient != null && !patient.isEmpty();
		case Research2Package.EPRESCRIPTION__DOCTOR:
			return doctor != null && !doctor.isEmpty();
		case Research2Package.EPRESCRIPTION__PRESCRIPTION:
			return prescription != null && !prescription.isEmpty();
		case Research2Package.EPRESCRIPTION__HISTORY:
			return history != null && !history.isEmpty();
		case Research2Package.EPRESCRIPTION__RECOMMENDATIONSYSTEM:
			return recommendationsystem != null && !recommendationsystem.isEmpty();
		case Research2Package.EPRESCRIPTION__PHARMACIST:
			return pharmacist != null && !pharmacist.isEmpty();
		case Research2Package.EPRESCRIPTION__STOCK:
			return stock != null && !stock.isEmpty();
		case Research2Package.EPRESCRIPTION__CLASSIFIER:
			return classifier != null && !classifier.isEmpty();
		case Research2Package.EPRESCRIPTION__PREDICTION:
			return prediction != null && !prediction.isEmpty();
		case Research2Package.EPRESCRIPTION__LIST:
			return list != null && !list.isEmpty();
		case Research2Package.EPRESCRIPTION__DIESEASE:
			return diesease != null && !diesease.isEmpty();
		case Research2Package.EPRESCRIPTION__DRUG:
			return drug != null && !drug.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //EPrescriptionImpl
