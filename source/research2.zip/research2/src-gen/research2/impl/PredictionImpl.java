/**
 */
package research2.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import research2.List;
import research2.Prediction;
import research2.Research2Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Prediction</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link research2.impl.PredictionImpl#getPredictedDrug <em>Predicted Drug</em>}</li>
 *   <li>{@link research2.impl.PredictionImpl#getList <em>List</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PredictionImpl extends MinimalEObjectImpl.Container implements Prediction {
	/**
	 * The default value of the '{@link #getPredictedDrug() <em>Predicted Drug</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPredictedDrug()
	 * @generated
	 * @ordered
	 */
	protected static final String PREDICTED_DRUG_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPredictedDrug() <em>Predicted Drug</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPredictedDrug()
	 * @generated
	 * @ordered
	 */
	protected String predictedDrug = PREDICTED_DRUG_EDEFAULT;

	/**
	 * The cached value of the '{@link #getList() <em>List</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getList()
	 * @generated
	 * @ordered
	 */
	protected List list;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PredictionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Research2Package.Literals.PREDICTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPredictedDrug() {
		return predictedDrug;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPredictedDrug(String newPredictedDrug) {
		String oldPredictedDrug = predictedDrug;
		predictedDrug = newPredictedDrug;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.PREDICTION__PREDICTED_DRUG,
					oldPredictedDrug, predictedDrug));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List getList() {
		if (list != null && list.eIsProxy()) {
			InternalEObject oldList = (InternalEObject) list;
			list = (List) eResolveProxy(oldList);
			if (list != oldList) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Research2Package.PREDICTION__LIST,
							oldList, list));
			}
		}
		return list;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List basicGetList() {
		return list;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setList(List newList) {
		List oldList = list;
		list = newList;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.PREDICTION__LIST, oldList, list));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Research2Package.PREDICTION__PREDICTED_DRUG:
			return getPredictedDrug();
		case Research2Package.PREDICTION__LIST:
			if (resolve)
				return getList();
			return basicGetList();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Research2Package.PREDICTION__PREDICTED_DRUG:
			setPredictedDrug((String) newValue);
			return;
		case Research2Package.PREDICTION__LIST:
			setList((List) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Research2Package.PREDICTION__PREDICTED_DRUG:
			setPredictedDrug(PREDICTED_DRUG_EDEFAULT);
			return;
		case Research2Package.PREDICTION__LIST:
			setList((List) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Research2Package.PREDICTION__PREDICTED_DRUG:
			return PREDICTED_DRUG_EDEFAULT == null ? predictedDrug != null
					: !PREDICTED_DRUG_EDEFAULT.equals(predictedDrug);
		case Research2Package.PREDICTION__LIST:
			return list != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (predictedDrug: ");
		result.append(predictedDrug);
		result.append(')');
		return result.toString();
	}

} //PredictionImpl
