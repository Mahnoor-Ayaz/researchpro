/**
 */
package research2.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import research2.Doctor;
import research2.Patient;
import research2.Prescription;
import research2.Research2Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Doctor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link research2.impl.DoctorImpl#getHavepatient <em>Havepatient</em>}</li>
 *   <li>{@link research2.impl.DoctorImpl#getDprescription <em>Dprescription</em>}</li>
 *   <li>{@link research2.impl.DoctorImpl#getName <em>Name</em>}</li>
 *   <li>{@link research2.impl.DoctorImpl#getDoctorId <em>Doctor Id</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DoctorImpl extends MinimalEObjectImpl.Container implements Doctor {
	/**
	 * The cached value of the '{@link #getHavepatient() <em>Havepatient</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHavepatient()
	 * @generated
	 * @ordered
	 */
	protected EList<Patient> havepatient;

	/**
	 * The cached value of the '{@link #getDprescription() <em>Dprescription</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDprescription()
	 * @generated
	 * @ordered
	 */
	protected EList<Prescription> dprescription;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoctorId() <em>Doctor Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoctorId()
	 * @generated
	 * @ordered
	 */
	protected static final int DOCTOR_ID_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getDoctorId() <em>Doctor Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoctorId()
	 * @generated
	 * @ordered
	 */
	protected int doctorId = DOCTOR_ID_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DoctorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Research2Package.Literals.DOCTOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Patient> getHavepatient() {
		if (havepatient == null) {
			havepatient = new EObjectWithInverseResolvingEList<Patient>(Patient.class, this,
					Research2Package.DOCTOR__HAVEPATIENT, Research2Package.PATIENT__HAVEDOCTOR);
		}
		return havepatient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Prescription> getDprescription() {
		if (dprescription == null) {
			dprescription = new EObjectWithInverseResolvingEList<Prescription>(Prescription.class, this,
					Research2Package.DOCTOR__DPRESCRIPTION, Research2Package.PRESCRIPTION__PDOCTOR);
		}
		return dprescription;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.DOCTOR__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getDoctorId() {
		return doctorId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoctorId(int newDoctorId) {
		int oldDoctorId = doctorId;
		doctorId = newDoctorId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.DOCTOR__DOCTOR_ID, oldDoctorId,
					doctorId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Research2Package.DOCTOR__HAVEPATIENT:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getHavepatient()).basicAdd(otherEnd, msgs);
		case Research2Package.DOCTOR__DPRESCRIPTION:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getDprescription()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Research2Package.DOCTOR__HAVEPATIENT:
			return ((InternalEList<?>) getHavepatient()).basicRemove(otherEnd, msgs);
		case Research2Package.DOCTOR__DPRESCRIPTION:
			return ((InternalEList<?>) getDprescription()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Research2Package.DOCTOR__HAVEPATIENT:
			return getHavepatient();
		case Research2Package.DOCTOR__DPRESCRIPTION:
			return getDprescription();
		case Research2Package.DOCTOR__NAME:
			return getName();
		case Research2Package.DOCTOR__DOCTOR_ID:
			return getDoctorId();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Research2Package.DOCTOR__HAVEPATIENT:
			getHavepatient().clear();
			getHavepatient().addAll((Collection<? extends Patient>) newValue);
			return;
		case Research2Package.DOCTOR__DPRESCRIPTION:
			getDprescription().clear();
			getDprescription().addAll((Collection<? extends Prescription>) newValue);
			return;
		case Research2Package.DOCTOR__NAME:
			setName((String) newValue);
			return;
		case Research2Package.DOCTOR__DOCTOR_ID:
			setDoctorId((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Research2Package.DOCTOR__HAVEPATIENT:
			getHavepatient().clear();
			return;
		case Research2Package.DOCTOR__DPRESCRIPTION:
			getDprescription().clear();
			return;
		case Research2Package.DOCTOR__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Research2Package.DOCTOR__DOCTOR_ID:
			setDoctorId(DOCTOR_ID_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Research2Package.DOCTOR__HAVEPATIENT:
			return havepatient != null && !havepatient.isEmpty();
		case Research2Package.DOCTOR__DPRESCRIPTION:
			return dprescription != null && !dprescription.isEmpty();
		case Research2Package.DOCTOR__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Research2Package.DOCTOR__DOCTOR_ID:
			return doctorId != DOCTOR_ID_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", doctorId: ");
		result.append(doctorId);
		result.append(')');
		return result.toString();
	}

} //DoctorImpl
