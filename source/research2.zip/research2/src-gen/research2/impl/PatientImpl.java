/**
 */
package research2.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import research2.Doctor;
import research2.History;
import research2.Patient;
import research2.Prescription;
import research2.Research2Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Patient</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link research2.impl.PatientImpl#getHistory <em>History</em>}</li>
 *   <li>{@link research2.impl.PatientImpl#getGetprescription <em>Getprescription</em>}</li>
 *   <li>{@link research2.impl.PatientImpl#getHavedoctor <em>Havedoctor</em>}</li>
 *   <li>{@link research2.impl.PatientImpl#getName <em>Name</em>}</li>
 *   <li>{@link research2.impl.PatientImpl#getPatientId <em>Patient Id</em>}</li>
 *   <li>{@link research2.impl.PatientImpl#getAge <em>Age</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PatientImpl extends MinimalEObjectImpl.Container implements Patient {
	/**
	 * The cached value of the '{@link #getHistory() <em>History</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHistory()
	 * @generated
	 * @ordered
	 */
	protected EList<History> history;

	/**
	 * The cached value of the '{@link #getGetprescription() <em>Getprescription</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGetprescription()
	 * @generated
	 * @ordered
	 */
	protected EList<Prescription> getprescription;

	/**
	 * The cached value of the '{@link #getHavedoctor() <em>Havedoctor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHavedoctor()
	 * @generated
	 * @ordered
	 */
	protected Doctor havedoctor;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getPatientId() <em>Patient Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPatientId()
	 * @generated
	 * @ordered
	 */
	protected static final String PATIENT_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPatientId() <em>Patient Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPatientId()
	 * @generated
	 * @ordered
	 */
	protected String patientId = PATIENT_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getAge() <em>Age</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAge()
	 * @generated
	 * @ordered
	 */
	protected static final int AGE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getAge() <em>Age</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAge()
	 * @generated
	 * @ordered
	 */
	protected int age = AGE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PatientImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Research2Package.Literals.PATIENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<History> getHistory() {
		if (history == null) {
			history = new EObjectWithInverseResolvingEList<History>(History.class, this,
					Research2Package.PATIENT__HISTORY, Research2Package.HISTORY__PATIENT);
		}
		return history;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Prescription> getGetprescription() {
		if (getprescription == null) {
			getprescription = new EObjectWithInverseResolvingEList<Prescription>(Prescription.class, this,
					Research2Package.PATIENT__GETPRESCRIPTION, Research2Package.PRESCRIPTION__PATIENT);
		}
		return getprescription;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Doctor getHavedoctor() {
		if (havedoctor != null && havedoctor.eIsProxy()) {
			InternalEObject oldHavedoctor = (InternalEObject) havedoctor;
			havedoctor = (Doctor) eResolveProxy(oldHavedoctor);
			if (havedoctor != oldHavedoctor) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Research2Package.PATIENT__HAVEDOCTOR,
							oldHavedoctor, havedoctor));
			}
		}
		return havedoctor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Doctor basicGetHavedoctor() {
		return havedoctor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetHavedoctor(Doctor newHavedoctor, NotificationChain msgs) {
		Doctor oldHavedoctor = havedoctor;
		havedoctor = newHavedoctor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Research2Package.PATIENT__HAVEDOCTOR, oldHavedoctor, newHavedoctor);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHavedoctor(Doctor newHavedoctor) {
		if (newHavedoctor != havedoctor) {
			NotificationChain msgs = null;
			if (havedoctor != null)
				msgs = ((InternalEObject) havedoctor).eInverseRemove(this, Research2Package.DOCTOR__HAVEPATIENT,
						Doctor.class, msgs);
			if (newHavedoctor != null)
				msgs = ((InternalEObject) newHavedoctor).eInverseAdd(this, Research2Package.DOCTOR__HAVEPATIENT,
						Doctor.class, msgs);
			msgs = basicSetHavedoctor(newHavedoctor, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.PATIENT__HAVEDOCTOR, newHavedoctor,
					newHavedoctor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.PATIENT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPatientId() {
		return patientId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPatientId(String newPatientId) {
		String oldPatientId = patientId;
		patientId = newPatientId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.PATIENT__PATIENT_ID, oldPatientId,
					patientId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getAge() {
		return age;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAge(int newAge) {
		int oldAge = age;
		age = newAge;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.PATIENT__AGE, oldAge, age));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Research2Package.PATIENT__HISTORY:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getHistory()).basicAdd(otherEnd, msgs);
		case Research2Package.PATIENT__GETPRESCRIPTION:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getGetprescription()).basicAdd(otherEnd, msgs);
		case Research2Package.PATIENT__HAVEDOCTOR:
			if (havedoctor != null)
				msgs = ((InternalEObject) havedoctor).eInverseRemove(this, Research2Package.DOCTOR__HAVEPATIENT,
						Doctor.class, msgs);
			return basicSetHavedoctor((Doctor) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Research2Package.PATIENT__HISTORY:
			return ((InternalEList<?>) getHistory()).basicRemove(otherEnd, msgs);
		case Research2Package.PATIENT__GETPRESCRIPTION:
			return ((InternalEList<?>) getGetprescription()).basicRemove(otherEnd, msgs);
		case Research2Package.PATIENT__HAVEDOCTOR:
			return basicSetHavedoctor(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Research2Package.PATIENT__HISTORY:
			return getHistory();
		case Research2Package.PATIENT__GETPRESCRIPTION:
			return getGetprescription();
		case Research2Package.PATIENT__HAVEDOCTOR:
			if (resolve)
				return getHavedoctor();
			return basicGetHavedoctor();
		case Research2Package.PATIENT__NAME:
			return getName();
		case Research2Package.PATIENT__PATIENT_ID:
			return getPatientId();
		case Research2Package.PATIENT__AGE:
			return getAge();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Research2Package.PATIENT__HISTORY:
			getHistory().clear();
			getHistory().addAll((Collection<? extends History>) newValue);
			return;
		case Research2Package.PATIENT__GETPRESCRIPTION:
			getGetprescription().clear();
			getGetprescription().addAll((Collection<? extends Prescription>) newValue);
			return;
		case Research2Package.PATIENT__HAVEDOCTOR:
			setHavedoctor((Doctor) newValue);
			return;
		case Research2Package.PATIENT__NAME:
			setName((String) newValue);
			return;
		case Research2Package.PATIENT__PATIENT_ID:
			setPatientId((String) newValue);
			return;
		case Research2Package.PATIENT__AGE:
			setAge((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Research2Package.PATIENT__HISTORY:
			getHistory().clear();
			return;
		case Research2Package.PATIENT__GETPRESCRIPTION:
			getGetprescription().clear();
			return;
		case Research2Package.PATIENT__HAVEDOCTOR:
			setHavedoctor((Doctor) null);
			return;
		case Research2Package.PATIENT__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Research2Package.PATIENT__PATIENT_ID:
			setPatientId(PATIENT_ID_EDEFAULT);
			return;
		case Research2Package.PATIENT__AGE:
			setAge(AGE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Research2Package.PATIENT__HISTORY:
			return history != null && !history.isEmpty();
		case Research2Package.PATIENT__GETPRESCRIPTION:
			return getprescription != null && !getprescription.isEmpty();
		case Research2Package.PATIENT__HAVEDOCTOR:
			return havedoctor != null;
		case Research2Package.PATIENT__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Research2Package.PATIENT__PATIENT_ID:
			return PATIENT_ID_EDEFAULT == null ? patientId != null : !PATIENT_ID_EDEFAULT.equals(patientId);
		case Research2Package.PATIENT__AGE:
			return age != AGE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", patientId: ");
		result.append(patientId);
		result.append(", age: ");
		result.append(age);
		result.append(')');
		return result.toString();
	}

} //PatientImpl
