/**
 */
package research2.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import research2.Classifier;
import research2.DecisionTree;
import research2.Diesease;
import research2.Doctor;
import research2.Drug;
import research2.DrugType;
import research2.EPrescription;
import research2.FeatureExtraction;
import research2.History;
import research2.List;
import research2.Model;
import research2.NeuralNetwork;
import research2.Patient;
import research2.Pharmacist;
import research2.Prediction;
import research2.Prescription;
import research2.RandomForest;
import research2.RecommendationSystem;
import research2.Research2Factory;
import research2.Research2Package;
import research2.Severity;
import research2.Stock;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Research2PackageImpl extends EPackageImpl implements Research2Package {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ePrescriptionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass patientEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dieseaseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass drugEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass classifierEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass decisionTreeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass modelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass neuralNetworkEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass prescriptionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass randomForestEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass stockEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass pharmacistEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass doctorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass historyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass recommendationSystemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass featureExtractionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass predictionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass listEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum drugTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum severityEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see research2.Research2Package#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private Research2PackageImpl() {
		super(eNS_URI, Research2Factory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link Research2Package#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static Research2Package init() {
		if (isInited)
			return (Research2Package) EPackage.Registry.INSTANCE.getEPackage(Research2Package.eNS_URI);

		// Obtain or create and register package
		Object registeredResearch2Package = EPackage.Registry.INSTANCE.get(eNS_URI);
		Research2PackageImpl theResearch2Package = registeredResearch2Package instanceof Research2PackageImpl
				? (Research2PackageImpl) registeredResearch2Package
				: new Research2PackageImpl();

		isInited = true;

		// Create package meta-data objects
		theResearch2Package.createPackageContents();

		// Initialize created meta-data
		theResearch2Package.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theResearch2Package.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(Research2Package.eNS_URI, theResearch2Package);
		return theResearch2Package;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEPrescription() {
		return ePrescriptionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEPrescription_Patient() {
		return (EReference) ePrescriptionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEPrescription_Doctor() {
		return (EReference) ePrescriptionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEPrescription_Prescription() {
		return (EReference) ePrescriptionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEPrescription_History() {
		return (EReference) ePrescriptionEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEPrescription_Recommendationsystem() {
		return (EReference) ePrescriptionEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEPrescription_Pharmacist() {
		return (EReference) ePrescriptionEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEPrescription_Stock() {
		return (EReference) ePrescriptionEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEPrescription_Classifier() {
		return (EReference) ePrescriptionEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEPrescription_Prediction() {
		return (EReference) ePrescriptionEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEPrescription_List() {
		return (EReference) ePrescriptionEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEPrescription_Diesease() {
		return (EReference) ePrescriptionEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEPrescription_Drug() {
		return (EReference) ePrescriptionEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPatient() {
		return patientEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatient_History() {
		return (EReference) patientEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatient_Getprescription() {
		return (EReference) patientEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatient_Havedoctor() {
		return (EReference) patientEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPatient_Name() {
		return (EAttribute) patientEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPatient_PatientId() {
		return (EAttribute) patientEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPatient_Age() {
		return (EAttribute) patientEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDiesease() {
		return dieseaseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDiesease_Ofdrug() {
		return (EReference) dieseaseEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDiesease_Name() {
		return (EAttribute) dieseaseEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDiesease_Severity() {
		return (EAttribute) dieseaseEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDrug() {
		return drugEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDrug_Ofdiesease() {
		return (EReference) drugEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDrug_Type() {
		return (EAttribute) drugEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDrug_Name() {
		return (EAttribute) drugEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDrug_Price() {
		return (EAttribute) drugEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDrug_ManufactoringDate() {
		return (EAttribute) drugEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDrug_ExpiryDate() {
		return (EAttribute) drugEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getClassifier() {
		return classifierEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getClassifier_Prediction() {
		return (EReference) classifierEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getClassifier_Name() {
		return (EAttribute) classifierEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getClassifier_Dataset() {
		return (EAttribute) classifierEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getClassifier_Featureextraction() {
		return (EReference) classifierEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getClassifier_Model() {
		return (EReference) classifierEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassifier__Classify() {
		return classifierEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDecisionTree() {
		return decisionTreeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDecisionTree_Name() {
		return (EAttribute) decisionTreeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDecisionTree__Trainningdata() {
		return decisionTreeEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDecisionTree__Testingdata() {
		return decisionTreeEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDecisionTree__Predict() {
		return decisionTreeEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDecisionTree__Recall() {
		return decisionTreeEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getModel() {
		return modelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNeuralNetwork() {
		return neuralNetworkEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNeuralNetwork_Name() {
		return (EAttribute) neuralNetworkEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getNeuralNetwork__Trainingdats() {
		return neuralNetworkEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getNeuralNetwork__Testingdata() {
		return neuralNetworkEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getNeuralNetwork__Predict() {
		return neuralNetworkEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getNeuralNetwork__Recall() {
		return neuralNetworkEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPrescription() {
		return prescriptionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPrescription_Havedrug() {
		return (EReference) prescriptionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPrescription_Patient() {
		return (EReference) prescriptionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPrescription_Pdoctor() {
		return (EReference) prescriptionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPrescription_Quantity() {
		return (EAttribute) prescriptionEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPrescription_PrescriptionId() {
		return (EAttribute) prescriptionEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPrescription_Drugname() {
		return (EAttribute) prescriptionEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRandomForest() {
		return randomForestEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRandomForest_Name() {
		return (EAttribute) randomForestEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRandomForest__Trainingdata() {
		return randomForestEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRandomForest__Testingdata() {
		return randomForestEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRandomForest__Predict() {
		return randomForestEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRandomForest__Recall() {
		return randomForestEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStock() {
		return stockEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStock_Drugs() {
		return (EAttribute) stockEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStock__Checkavailability() {
		return stockEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPharmacist() {
		return pharmacistEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPharmacist_Get() {
		return (EReference) pharmacistEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPharmacist_Checkstock() {
		return (EReference) pharmacistEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPharmacist_Name() {
		return (EAttribute) pharmacistEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPharmacist_PharmacitId() {
		return (EAttribute) pharmacistEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDoctor() {
		return doctorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDoctor_Havepatient() {
		return (EReference) doctorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDoctor_Dprescription() {
		return (EReference) doctorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDoctor_Name() {
		return (EAttribute) doctorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDoctor_DoctorId() {
		return (EAttribute) doctorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getHistory() {
		return historyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHistory_Patient() {
		return (EReference) historyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHistory_Containdiesease() {
		return (EReference) historyEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHistory_Containdrug() {
		return (EReference) historyEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHistory_Name() {
		return (EAttribute) historyEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getHistory__View() {
		return historyEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getHistory__Modify() {
		return historyEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRecommendationSystem() {
		return recommendationSystemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRecommendationSystem_Classifier() {
		return (EReference) recommendationSystemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRecommendationSystem_Title() {
		return (EAttribute) recommendationSystemEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRecommendationSystem_List() {
		return (EReference) recommendationSystemEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFeatureExtraction() {
		return featureExtractionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFeatureExtraction_Feature() {
		return (EAttribute) featureExtractionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFeatureExtraction_Label() {
		return (EAttribute) featureExtractionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFeatureExtraction_History() {
		return (EReference) featureExtractionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFeatureExtraction__Extract() {
		return featureExtractionEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPrediction() {
		return predictionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPrediction_PredictedDrug() {
		return (EAttribute) predictionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPrediction_List() {
		return (EReference) predictionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getList() {
		return listEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getList_Goesto() {
		return (EReference) listEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getList_Title() {
		return (EAttribute) listEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getDrugType() {
		return drugTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getSeverity() {
		return severityEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Research2Factory getResearch2Factory() {
		return (Research2Factory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		ePrescriptionEClass = createEClass(EPRESCRIPTION);
		createEReference(ePrescriptionEClass, EPRESCRIPTION__PATIENT);
		createEReference(ePrescriptionEClass, EPRESCRIPTION__DOCTOR);
		createEReference(ePrescriptionEClass, EPRESCRIPTION__PRESCRIPTION);
		createEReference(ePrescriptionEClass, EPRESCRIPTION__HISTORY);
		createEReference(ePrescriptionEClass, EPRESCRIPTION__RECOMMENDATIONSYSTEM);
		createEReference(ePrescriptionEClass, EPRESCRIPTION__PHARMACIST);
		createEReference(ePrescriptionEClass, EPRESCRIPTION__STOCK);
		createEReference(ePrescriptionEClass, EPRESCRIPTION__CLASSIFIER);
		createEReference(ePrescriptionEClass, EPRESCRIPTION__PREDICTION);
		createEReference(ePrescriptionEClass, EPRESCRIPTION__LIST);
		createEReference(ePrescriptionEClass, EPRESCRIPTION__DIESEASE);
		createEReference(ePrescriptionEClass, EPRESCRIPTION__DRUG);

		patientEClass = createEClass(PATIENT);
		createEReference(patientEClass, PATIENT__HISTORY);
		createEReference(patientEClass, PATIENT__GETPRESCRIPTION);
		createEReference(patientEClass, PATIENT__HAVEDOCTOR);
		createEAttribute(patientEClass, PATIENT__NAME);
		createEAttribute(patientEClass, PATIENT__PATIENT_ID);
		createEAttribute(patientEClass, PATIENT__AGE);

		dieseaseEClass = createEClass(DIESEASE);
		createEReference(dieseaseEClass, DIESEASE__OFDRUG);
		createEAttribute(dieseaseEClass, DIESEASE__NAME);
		createEAttribute(dieseaseEClass, DIESEASE__SEVERITY);

		drugEClass = createEClass(DRUG);
		createEReference(drugEClass, DRUG__OFDIESEASE);
		createEAttribute(drugEClass, DRUG__TYPE);
		createEAttribute(drugEClass, DRUG__NAME);
		createEAttribute(drugEClass, DRUG__PRICE);
		createEAttribute(drugEClass, DRUG__MANUFACTORING_DATE);
		createEAttribute(drugEClass, DRUG__EXPIRY_DATE);

		classifierEClass = createEClass(CLASSIFIER);
		createEReference(classifierEClass, CLASSIFIER__PREDICTION);
		createEAttribute(classifierEClass, CLASSIFIER__NAME);
		createEAttribute(classifierEClass, CLASSIFIER__DATASET);
		createEReference(classifierEClass, CLASSIFIER__FEATUREEXTRACTION);
		createEReference(classifierEClass, CLASSIFIER__MODEL);
		createEOperation(classifierEClass, CLASSIFIER___CLASSIFY);

		decisionTreeEClass = createEClass(DECISION_TREE);
		createEAttribute(decisionTreeEClass, DECISION_TREE__NAME);
		createEOperation(decisionTreeEClass, DECISION_TREE___TRAINNINGDATA);
		createEOperation(decisionTreeEClass, DECISION_TREE___TESTINGDATA);
		createEOperation(decisionTreeEClass, DECISION_TREE___PREDICT);
		createEOperation(decisionTreeEClass, DECISION_TREE___RECALL);

		modelEClass = createEClass(MODEL);

		neuralNetworkEClass = createEClass(NEURAL_NETWORK);
		createEAttribute(neuralNetworkEClass, NEURAL_NETWORK__NAME);
		createEOperation(neuralNetworkEClass, NEURAL_NETWORK___TRAININGDATS);
		createEOperation(neuralNetworkEClass, NEURAL_NETWORK___TESTINGDATA);
		createEOperation(neuralNetworkEClass, NEURAL_NETWORK___PREDICT);
		createEOperation(neuralNetworkEClass, NEURAL_NETWORK___RECALL);

		prescriptionEClass = createEClass(PRESCRIPTION);
		createEReference(prescriptionEClass, PRESCRIPTION__HAVEDRUG);
		createEReference(prescriptionEClass, PRESCRIPTION__PATIENT);
		createEReference(prescriptionEClass, PRESCRIPTION__PDOCTOR);
		createEAttribute(prescriptionEClass, PRESCRIPTION__QUANTITY);
		createEAttribute(prescriptionEClass, PRESCRIPTION__PRESCRIPTION_ID);
		createEAttribute(prescriptionEClass, PRESCRIPTION__DRUGNAME);

		randomForestEClass = createEClass(RANDOM_FOREST);
		createEAttribute(randomForestEClass, RANDOM_FOREST__NAME);
		createEOperation(randomForestEClass, RANDOM_FOREST___TRAININGDATA);
		createEOperation(randomForestEClass, RANDOM_FOREST___TESTINGDATA);
		createEOperation(randomForestEClass, RANDOM_FOREST___PREDICT);
		createEOperation(randomForestEClass, RANDOM_FOREST___RECALL);

		stockEClass = createEClass(STOCK);
		createEAttribute(stockEClass, STOCK__DRUGS);
		createEOperation(stockEClass, STOCK___CHECKAVAILABILITY);

		pharmacistEClass = createEClass(PHARMACIST);
		createEReference(pharmacistEClass, PHARMACIST__GET);
		createEReference(pharmacistEClass, PHARMACIST__CHECKSTOCK);
		createEAttribute(pharmacistEClass, PHARMACIST__NAME);
		createEAttribute(pharmacistEClass, PHARMACIST__PHARMACIT_ID);

		doctorEClass = createEClass(DOCTOR);
		createEReference(doctorEClass, DOCTOR__HAVEPATIENT);
		createEReference(doctorEClass, DOCTOR__DPRESCRIPTION);
		createEAttribute(doctorEClass, DOCTOR__NAME);
		createEAttribute(doctorEClass, DOCTOR__DOCTOR_ID);

		historyEClass = createEClass(HISTORY);
		createEReference(historyEClass, HISTORY__PATIENT);
		createEReference(historyEClass, HISTORY__CONTAINDIESEASE);
		createEReference(historyEClass, HISTORY__CONTAINDRUG);
		createEAttribute(historyEClass, HISTORY__NAME);
		createEOperation(historyEClass, HISTORY___VIEW);
		createEOperation(historyEClass, HISTORY___MODIFY);

		recommendationSystemEClass = createEClass(RECOMMENDATION_SYSTEM);
		createEReference(recommendationSystemEClass, RECOMMENDATION_SYSTEM__CLASSIFIER);
		createEAttribute(recommendationSystemEClass, RECOMMENDATION_SYSTEM__TITLE);
		createEReference(recommendationSystemEClass, RECOMMENDATION_SYSTEM__LIST);

		featureExtractionEClass = createEClass(FEATURE_EXTRACTION);
		createEAttribute(featureExtractionEClass, FEATURE_EXTRACTION__FEATURE);
		createEAttribute(featureExtractionEClass, FEATURE_EXTRACTION__LABEL);
		createEReference(featureExtractionEClass, FEATURE_EXTRACTION__HISTORY);
		createEOperation(featureExtractionEClass, FEATURE_EXTRACTION___EXTRACT);

		predictionEClass = createEClass(PREDICTION);
		createEAttribute(predictionEClass, PREDICTION__PREDICTED_DRUG);
		createEReference(predictionEClass, PREDICTION__LIST);

		listEClass = createEClass(LIST);
		createEReference(listEClass, LIST__GOESTO);
		createEAttribute(listEClass, LIST__TITLE);

		// Create enums
		drugTypeEEnum = createEEnum(DRUG_TYPE);
		severityEEnum = createEEnum(SEVERITY);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		decisionTreeEClass.getESuperTypes().add(this.getModel());
		neuralNetworkEClass.getESuperTypes().add(this.getModel());
		randomForestEClass.getESuperTypes().add(this.getModel());

		// Initialize classes, features, and operations; add parameters
		initEClass(ePrescriptionEClass, EPrescription.class, "EPrescription", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getEPrescription_Patient(), this.getPatient(), null, "patient", null, 0, -1, EPrescription.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEPrescription_Doctor(), this.getDoctor(), null, "doctor", null, 0, -1, EPrescription.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEPrescription_Prescription(), this.getPrescription(), null, "prescription", null, 0, -1,
				EPrescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEPrescription_History(), this.getHistory(), null, "history", null, 0, -1, EPrescription.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEPrescription_Recommendationsystem(), this.getRecommendationSystem(), null,
				"recommendationsystem", null, 0, -1, EPrescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEPrescription_Pharmacist(), this.getPharmacist(), null, "pharmacist", null, 0, -1,
				EPrescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEPrescription_Stock(), this.getStock(), null, "stock", null, 0, -1, EPrescription.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEPrescription_Classifier(), this.getClassifier(), null, "classifier", null, 0, -1,
				EPrescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEPrescription_Prediction(), this.getPrediction(), null, "prediction", null, 0, -1,
				EPrescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEPrescription_List(), this.getList(), null, "list", null, 0, -1, EPrescription.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEPrescription_Diesease(), this.getDiesease(), null, "diesease", null, 0, -1,
				EPrescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEPrescription_Drug(), this.getDrug(), null, "drug", null, 0, -1, EPrescription.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(patientEClass, Patient.class, "Patient", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPatient_History(), this.getHistory(), this.getHistory_Patient(), "history", null, 0, -1,
				Patient.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPatient_Getprescription(), this.getPrescription(), this.getPrescription_Patient(),
				"getprescription", null, 0, -1, Patient.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPatient_Havedoctor(), this.getDoctor(), this.getDoctor_Havepatient(), "havedoctor", null, 1,
				1, Patient.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPatient_Name(), ecorePackage.getEString(), "name", null, 0, 1, Patient.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPatient_PatientId(), ecorePackage.getEString(), "patientId", null, 0, 1, Patient.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPatient_Age(), ecorePackage.getEInt(), "age", null, 0, 1, Patient.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(dieseaseEClass, Diesease.class, "Diesease", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDiesease_Ofdrug(), this.getDrug(), this.getDrug_Ofdiesease(), "ofdrug", null, 0, -1,
				Diesease.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDiesease_Name(), ecorePackage.getEString(), "name", null, 0, 1, Diesease.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDiesease_Severity(), this.getSeverity(), "severity", null, 0, 1, Diesease.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(drugEClass, Drug.class, "Drug", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDrug_Ofdiesease(), this.getDiesease(), this.getDiesease_Ofdrug(), "ofdiesease", null, 1, -1,
				Drug.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDrug_Type(), this.getDrugType(), "type", null, 0, 1, Drug.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDrug_Name(), ecorePackage.getEString(), "name", null, 0, 1, Drug.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDrug_Price(), ecorePackage.getEInt(), "price", null, 0, 1, Drug.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDrug_ManufactoringDate(), ecorePackage.getEDate(), "manufactoringDate", null, 0, 1,
				Drug.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEAttribute(getDrug_ExpiryDate(), ecorePackage.getEDate(), "expiryDate", null, 0, 1, Drug.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(classifierEClass, Classifier.class, "Classifier", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getClassifier_Prediction(), this.getPrediction(), null, "prediction", null, 0, 1,
				Classifier.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getClassifier_Name(), ecorePackage.getEString(), "name", null, 0, 1, Classifier.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getClassifier_Dataset(), ecorePackage.getEString(), "Dataset", null, 0, 1, Classifier.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getClassifier_Featureextraction(), this.getFeatureExtraction(), null, "featureextraction", null,
				0, -1, Classifier.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getClassifier_Model(), this.getModel(), null, "model", null, 0, -1, Classifier.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getClassifier__Classify(), null, "classify", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(decisionTreeEClass, DecisionTree.class, "DecisionTree", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDecisionTree_Name(), ecorePackage.getEString(), "name", null, 0, 1, DecisionTree.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getDecisionTree__Trainningdata(), null, "trainningdata", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getDecisionTree__Testingdata(), null, "testingdata", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getDecisionTree__Predict(), null, "predict", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getDecisionTree__Recall(), null, "recall", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(modelEClass, Model.class, "Model", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(neuralNetworkEClass, NeuralNetwork.class, "NeuralNetwork", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getNeuralNetwork_Name(), ecorePackage.getEString(), "name", null, 0, 1, NeuralNetwork.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getNeuralNetwork__Trainingdats(), null, "trainingdats", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getNeuralNetwork__Testingdata(), null, "testingdata", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getNeuralNetwork__Predict(), null, "predict", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getNeuralNetwork__Recall(), null, "recall", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(prescriptionEClass, Prescription.class, "Prescription", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPrescription_Havedrug(), this.getDrug(), null, "havedrug", null, 0, -1, Prescription.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPrescription_Patient(), this.getPatient(), this.getPatient_Getprescription(), "patient", null,
				1, 1, Prescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPrescription_Pdoctor(), this.getDoctor(), this.getDoctor_Dprescription(), "pdoctor", null, 1,
				1, Prescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPrescription_Quantity(), ecorePackage.getEInt(), "quantity", null, 0, 1, Prescription.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPrescription_PrescriptionId(), ecorePackage.getEInt(), "prescriptionId", null, 0, 1,
				Prescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getPrescription_Drugname(), ecorePackage.getEString(), "drugname", null, 0, 1,
				Prescription.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(randomForestEClass, RandomForest.class, "RandomForest", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRandomForest_Name(), ecorePackage.getEString(), "name", null, 0, 1, RandomForest.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getRandomForest__Trainingdata(), null, "trainingdata", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getRandomForest__Testingdata(), null, "testingdata", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getRandomForest__Predict(), null, "predict", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getRandomForest__Recall(), null, "recall", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(stockEClass, Stock.class, "Stock", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getStock_Drugs(), ecorePackage.getEString(), "drugs", null, 0, 1, Stock.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getStock__Checkavailability(), null, "checkavailability", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(pharmacistEClass, Pharmacist.class, "Pharmacist", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPharmacist_Get(), this.getPrescription(), null, "get", null, 0, -1, Pharmacist.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPharmacist_Checkstock(), this.getStock(), null, "checkstock", null, 0, -1, Pharmacist.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPharmacist_Name(), ecorePackage.getEString(), "name", null, 0, 1, Pharmacist.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPharmacist_PharmacitId(), ecorePackage.getEInt(), "pharmacitId", null, 0, 1, Pharmacist.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(doctorEClass, Doctor.class, "Doctor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDoctor_Havepatient(), this.getPatient(), this.getPatient_Havedoctor(), "havepatient", null, 0,
				-1, Doctor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDoctor_Dprescription(), this.getPrescription(), this.getPrescription_Pdoctor(),
				"dprescription", null, 0, -1, Doctor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDoctor_Name(), ecorePackage.getEString(), "name", null, 0, 1, Doctor.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDoctor_DoctorId(), ecorePackage.getEInt(), "doctorId", null, 0, 1, Doctor.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(historyEClass, History.class, "History", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getHistory_Patient(), this.getPatient(), this.getPatient_History(), "patient", null, 1, 1,
				History.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHistory_Containdiesease(), this.getDiesease(), null, "containdiesease", null, 1, -1,
				History.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHistory_Containdrug(), this.getDrug(), null, "containdrug", null, 1, -1, History.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getHistory_Name(), ecorePackage.getEString(), "name", null, 0, 1, History.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getHistory__View(), null, "view", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getHistory__Modify(), null, "modify", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(recommendationSystemEClass, RecommendationSystem.class, "RecommendationSystem", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRecommendationSystem_Classifier(), this.getClassifier(), null, "classifier", null, 0, 1,
				RecommendationSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRecommendationSystem_Title(), ecorePackage.getEString(), "title", null, 0, 1,
				RecommendationSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRecommendationSystem_List(), this.getList(), null, "list", null, 0, 1,
				RecommendationSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(featureExtractionEClass, FeatureExtraction.class, "FeatureExtraction", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFeatureExtraction_Feature(), ecorePackage.getEString(), "Feature", null, 0, 1,
				FeatureExtraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getFeatureExtraction_Label(), ecorePackage.getEString(), "label", null, 0, 1,
				FeatureExtraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getFeatureExtraction_History(), this.getHistory(), null, "history", null, 0, 1,
				FeatureExtraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getFeatureExtraction__Extract(), null, "extract", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(predictionEClass, Prediction.class, "Prediction", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPrediction_PredictedDrug(), ecorePackage.getEString(), "predictedDrug", null, 0, 1,
				Prediction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getPrediction_List(), this.getList(), null, "list", null, 1, 1, Prediction.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(listEClass, List.class, "List", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getList_Goesto(), this.getDoctor(), null, "goesto", null, 0, 1, List.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEAttribute(getList_Title(), ecorePackage.getEString(), "title", null, 0, 1, List.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(drugTypeEEnum, DrugType.class, "DrugType");
		addEEnumLiteral(drugTypeEEnum, DrugType.TABLET);
		addEEnumLiteral(drugTypeEEnum, DrugType.SYRUP);

		initEEnum(severityEEnum, Severity.class, "Severity");
		addEEnumLiteral(severityEEnum, Severity.L1);
		addEEnumLiteral(severityEEnum, Severity.L2);
		addEEnumLiteral(severityEEnum, Severity.L3);
		addEEnumLiteral(severityEEnum, Severity.L4);

		// Create resource
		createResource(eNS_URI);
	}

} //Research2PackageImpl
