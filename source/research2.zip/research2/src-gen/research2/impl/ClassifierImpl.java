/**
 */
package research2.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import research2.Classifier;
import research2.FeatureExtraction;
import research2.Model;
import research2.Prediction;
import research2.Research2Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Classifier</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link research2.impl.ClassifierImpl#getPrediction <em>Prediction</em>}</li>
 *   <li>{@link research2.impl.ClassifierImpl#getName <em>Name</em>}</li>
 *   <li>{@link research2.impl.ClassifierImpl#getDataset <em>Dataset</em>}</li>
 *   <li>{@link research2.impl.ClassifierImpl#getFeatureextraction <em>Featureextraction</em>}</li>
 *   <li>{@link research2.impl.ClassifierImpl#getModel <em>Model</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ClassifierImpl extends MinimalEObjectImpl.Container implements Classifier {
	/**
	 * The cached value of the '{@link #getPrediction() <em>Prediction</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrediction()
	 * @generated
	 * @ordered
	 */
	protected Prediction prediction;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getDataset() <em>Dataset</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataset()
	 * @generated
	 * @ordered
	 */
	protected static final String DATASET_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDataset() <em>Dataset</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataset()
	 * @generated
	 * @ordered
	 */
	protected String dataset = DATASET_EDEFAULT;

	/**
	 * The cached value of the '{@link #getFeatureextraction() <em>Featureextraction</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFeatureextraction()
	 * @generated
	 * @ordered
	 */
	protected EList<FeatureExtraction> featureextraction;

	/**
	 * The cached value of the '{@link #getModel() <em>Model</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModel()
	 * @generated
	 * @ordered
	 */
	protected EList<Model> model;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ClassifierImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Research2Package.Literals.CLASSIFIER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Prediction getPrediction() {
		if (prediction != null && prediction.eIsProxy()) {
			InternalEObject oldPrediction = (InternalEObject) prediction;
			prediction = (Prediction) eResolveProxy(oldPrediction);
			if (prediction != oldPrediction) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Research2Package.CLASSIFIER__PREDICTION,
							oldPrediction, prediction));
			}
		}
		return prediction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Prediction basicGetPrediction() {
		return prediction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrediction(Prediction newPrediction) {
		Prediction oldPrediction = prediction;
		prediction = newPrediction;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.CLASSIFIER__PREDICTION,
					oldPrediction, prediction));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.CLASSIFIER__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDataset() {
		return dataset;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDataset(String newDataset) {
		String oldDataset = dataset;
		dataset = newDataset;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.CLASSIFIER__DATASET, oldDataset,
					dataset));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FeatureExtraction> getFeatureextraction() {
		if (featureextraction == null) {
			featureextraction = new EObjectContainmentEList<FeatureExtraction>(FeatureExtraction.class, this,
					Research2Package.CLASSIFIER__FEATUREEXTRACTION);
		}
		return featureextraction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Model> getModel() {
		if (model == null) {
			model = new EObjectContainmentEList<Model>(Model.class, this, Research2Package.CLASSIFIER__MODEL);
		}
		return model;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void classify() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Research2Package.CLASSIFIER__FEATUREEXTRACTION:
			return ((InternalEList<?>) getFeatureextraction()).basicRemove(otherEnd, msgs);
		case Research2Package.CLASSIFIER__MODEL:
			return ((InternalEList<?>) getModel()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Research2Package.CLASSIFIER__PREDICTION:
			if (resolve)
				return getPrediction();
			return basicGetPrediction();
		case Research2Package.CLASSIFIER__NAME:
			return getName();
		case Research2Package.CLASSIFIER__DATASET:
			return getDataset();
		case Research2Package.CLASSIFIER__FEATUREEXTRACTION:
			return getFeatureextraction();
		case Research2Package.CLASSIFIER__MODEL:
			return getModel();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Research2Package.CLASSIFIER__PREDICTION:
			setPrediction((Prediction) newValue);
			return;
		case Research2Package.CLASSIFIER__NAME:
			setName((String) newValue);
			return;
		case Research2Package.CLASSIFIER__DATASET:
			setDataset((String) newValue);
			return;
		case Research2Package.CLASSIFIER__FEATUREEXTRACTION:
			getFeatureextraction().clear();
			getFeatureextraction().addAll((Collection<? extends FeatureExtraction>) newValue);
			return;
		case Research2Package.CLASSIFIER__MODEL:
			getModel().clear();
			getModel().addAll((Collection<? extends Model>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Research2Package.CLASSIFIER__PREDICTION:
			setPrediction((Prediction) null);
			return;
		case Research2Package.CLASSIFIER__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Research2Package.CLASSIFIER__DATASET:
			setDataset(DATASET_EDEFAULT);
			return;
		case Research2Package.CLASSIFIER__FEATUREEXTRACTION:
			getFeatureextraction().clear();
			return;
		case Research2Package.CLASSIFIER__MODEL:
			getModel().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Research2Package.CLASSIFIER__PREDICTION:
			return prediction != null;
		case Research2Package.CLASSIFIER__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Research2Package.CLASSIFIER__DATASET:
			return DATASET_EDEFAULT == null ? dataset != null : !DATASET_EDEFAULT.equals(dataset);
		case Research2Package.CLASSIFIER__FEATUREEXTRACTION:
			return featureextraction != null && !featureextraction.isEmpty();
		case Research2Package.CLASSIFIER__MODEL:
			return model != null && !model.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case Research2Package.CLASSIFIER___CLASSIFY:
			classify();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", Dataset: ");
		result.append(dataset);
		result.append(')');
		return result.toString();
	}

} //ClassifierImpl
