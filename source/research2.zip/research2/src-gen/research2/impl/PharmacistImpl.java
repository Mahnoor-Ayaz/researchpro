/**
 */
package research2.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import research2.Pharmacist;
import research2.Prescription;
import research2.Research2Package;
import research2.Stock;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pharmacist</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link research2.impl.PharmacistImpl#getGet <em>Get</em>}</li>
 *   <li>{@link research2.impl.PharmacistImpl#getCheckstock <em>Checkstock</em>}</li>
 *   <li>{@link research2.impl.PharmacistImpl#getName <em>Name</em>}</li>
 *   <li>{@link research2.impl.PharmacistImpl#getPharmacitId <em>Pharmacit Id</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PharmacistImpl extends MinimalEObjectImpl.Container implements Pharmacist {
	/**
	 * The cached value of the '{@link #getGet() <em>Get</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGet()
	 * @generated
	 * @ordered
	 */
	protected EList<Prescription> get;

	/**
	 * The cached value of the '{@link #getCheckstock() <em>Checkstock</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCheckstock()
	 * @generated
	 * @ordered
	 */
	protected EList<Stock> checkstock;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getPharmacitId() <em>Pharmacit Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPharmacitId()
	 * @generated
	 * @ordered
	 */
	protected static final int PHARMACIT_ID_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getPharmacitId() <em>Pharmacit Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPharmacitId()
	 * @generated
	 * @ordered
	 */
	protected int pharmacitId = PHARMACIT_ID_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PharmacistImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Research2Package.Literals.PHARMACIST;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Prescription> getGet() {
		if (get == null) {
			get = new EObjectResolvingEList<Prescription>(Prescription.class, this, Research2Package.PHARMACIST__GET);
		}
		return get;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Stock> getCheckstock() {
		if (checkstock == null) {
			checkstock = new EObjectResolvingEList<Stock>(Stock.class, this, Research2Package.PHARMACIST__CHECKSTOCK);
		}
		return checkstock;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.PHARMACIST__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getPharmacitId() {
		return pharmacitId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPharmacitId(int newPharmacitId) {
		int oldPharmacitId = pharmacitId;
		pharmacitId = newPharmacitId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.PHARMACIST__PHARMACIT_ID,
					oldPharmacitId, pharmacitId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Research2Package.PHARMACIST__GET:
			return getGet();
		case Research2Package.PHARMACIST__CHECKSTOCK:
			return getCheckstock();
		case Research2Package.PHARMACIST__NAME:
			return getName();
		case Research2Package.PHARMACIST__PHARMACIT_ID:
			return getPharmacitId();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Research2Package.PHARMACIST__GET:
			getGet().clear();
			getGet().addAll((Collection<? extends Prescription>) newValue);
			return;
		case Research2Package.PHARMACIST__CHECKSTOCK:
			getCheckstock().clear();
			getCheckstock().addAll((Collection<? extends Stock>) newValue);
			return;
		case Research2Package.PHARMACIST__NAME:
			setName((String) newValue);
			return;
		case Research2Package.PHARMACIST__PHARMACIT_ID:
			setPharmacitId((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Research2Package.PHARMACIST__GET:
			getGet().clear();
			return;
		case Research2Package.PHARMACIST__CHECKSTOCK:
			getCheckstock().clear();
			return;
		case Research2Package.PHARMACIST__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Research2Package.PHARMACIST__PHARMACIT_ID:
			setPharmacitId(PHARMACIT_ID_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Research2Package.PHARMACIST__GET:
			return get != null && !get.isEmpty();
		case Research2Package.PHARMACIST__CHECKSTOCK:
			return checkstock != null && !checkstock.isEmpty();
		case Research2Package.PHARMACIST__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Research2Package.PHARMACIST__PHARMACIT_ID:
			return pharmacitId != PHARMACIT_ID_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", pharmacitId: ");
		result.append(pharmacitId);
		result.append(')');
		return result.toString();
	}

} //PharmacistImpl
