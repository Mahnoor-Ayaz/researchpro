/**
 */
package research2.impl;

import java.util.Collection;
import java.util.Date;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import research2.Diesease;
import research2.Drug;
import research2.DrugType;
import research2.Research2Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Drug</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link research2.impl.DrugImpl#getOfdiesease <em>Ofdiesease</em>}</li>
 *   <li>{@link research2.impl.DrugImpl#getType <em>Type</em>}</li>
 *   <li>{@link research2.impl.DrugImpl#getName <em>Name</em>}</li>
 *   <li>{@link research2.impl.DrugImpl#getPrice <em>Price</em>}</li>
 *   <li>{@link research2.impl.DrugImpl#getManufactoringDate <em>Manufactoring Date</em>}</li>
 *   <li>{@link research2.impl.DrugImpl#getExpiryDate <em>Expiry Date</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DrugImpl extends MinimalEObjectImpl.Container implements Drug {
	/**
	 * The cached value of the '{@link #getOfdiesease() <em>Ofdiesease</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOfdiesease()
	 * @generated
	 * @ordered
	 */
	protected EList<Diesease> ofdiesease;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final DrugType TYPE_EDEFAULT = DrugType.TABLET;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected DrugType type = TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getPrice() <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrice()
	 * @generated
	 * @ordered
	 */
	protected static final int PRICE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getPrice() <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrice()
	 * @generated
	 * @ordered
	 */
	protected int price = PRICE_EDEFAULT;

	/**
	 * The default value of the '{@link #getManufactoringDate() <em>Manufactoring Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getManufactoringDate()
	 * @generated
	 * @ordered
	 */
	protected static final Date MANUFACTORING_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getManufactoringDate() <em>Manufactoring Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getManufactoringDate()
	 * @generated
	 * @ordered
	 */
	protected Date manufactoringDate = MANUFACTORING_DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getExpiryDate() <em>Expiry Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExpiryDate()
	 * @generated
	 * @ordered
	 */
	protected static final Date EXPIRY_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getExpiryDate() <em>Expiry Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExpiryDate()
	 * @generated
	 * @ordered
	 */
	protected Date expiryDate = EXPIRY_DATE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DrugImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Research2Package.Literals.DRUG;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Diesease> getOfdiesease() {
		if (ofdiesease == null) {
			ofdiesease = new EObjectWithInverseResolvingEList.ManyInverse<Diesease>(Diesease.class, this,
					Research2Package.DRUG__OFDIESEASE, Research2Package.DIESEASE__OFDRUG);
		}
		return ofdiesease;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DrugType getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(DrugType newType) {
		DrugType oldType = type;
		type = newType == null ? TYPE_EDEFAULT : newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.DRUG__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.DRUG__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getPrice() {
		return price;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrice(int newPrice) {
		int oldPrice = price;
		price = newPrice;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.DRUG__PRICE, oldPrice, price));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date getManufactoringDate() {
		return manufactoringDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setManufactoringDate(Date newManufactoringDate) {
		Date oldManufactoringDate = manufactoringDate;
		manufactoringDate = newManufactoringDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.DRUG__MANUFACTORING_DATE,
					oldManufactoringDate, manufactoringDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date getExpiryDate() {
		return expiryDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setExpiryDate(Date newExpiryDate) {
		Date oldExpiryDate = expiryDate;
		expiryDate = newExpiryDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.DRUG__EXPIRY_DATE, oldExpiryDate,
					expiryDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Research2Package.DRUG__OFDIESEASE:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getOfdiesease()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Research2Package.DRUG__OFDIESEASE:
			return ((InternalEList<?>) getOfdiesease()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Research2Package.DRUG__OFDIESEASE:
			return getOfdiesease();
		case Research2Package.DRUG__TYPE:
			return getType();
		case Research2Package.DRUG__NAME:
			return getName();
		case Research2Package.DRUG__PRICE:
			return getPrice();
		case Research2Package.DRUG__MANUFACTORING_DATE:
			return getManufactoringDate();
		case Research2Package.DRUG__EXPIRY_DATE:
			return getExpiryDate();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Research2Package.DRUG__OFDIESEASE:
			getOfdiesease().clear();
			getOfdiesease().addAll((Collection<? extends Diesease>) newValue);
			return;
		case Research2Package.DRUG__TYPE:
			setType((DrugType) newValue);
			return;
		case Research2Package.DRUG__NAME:
			setName((String) newValue);
			return;
		case Research2Package.DRUG__PRICE:
			setPrice((Integer) newValue);
			return;
		case Research2Package.DRUG__MANUFACTORING_DATE:
			setManufactoringDate((Date) newValue);
			return;
		case Research2Package.DRUG__EXPIRY_DATE:
			setExpiryDate((Date) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Research2Package.DRUG__OFDIESEASE:
			getOfdiesease().clear();
			return;
		case Research2Package.DRUG__TYPE:
			setType(TYPE_EDEFAULT);
			return;
		case Research2Package.DRUG__NAME:
			setName(NAME_EDEFAULT);
			return;
		case Research2Package.DRUG__PRICE:
			setPrice(PRICE_EDEFAULT);
			return;
		case Research2Package.DRUG__MANUFACTORING_DATE:
			setManufactoringDate(MANUFACTORING_DATE_EDEFAULT);
			return;
		case Research2Package.DRUG__EXPIRY_DATE:
			setExpiryDate(EXPIRY_DATE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Research2Package.DRUG__OFDIESEASE:
			return ofdiesease != null && !ofdiesease.isEmpty();
		case Research2Package.DRUG__TYPE:
			return type != TYPE_EDEFAULT;
		case Research2Package.DRUG__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case Research2Package.DRUG__PRICE:
			return price != PRICE_EDEFAULT;
		case Research2Package.DRUG__MANUFACTORING_DATE:
			return MANUFACTORING_DATE_EDEFAULT == null ? manufactoringDate != null
					: !MANUFACTORING_DATE_EDEFAULT.equals(manufactoringDate);
		case Research2Package.DRUG__EXPIRY_DATE:
			return EXPIRY_DATE_EDEFAULT == null ? expiryDate != null : !EXPIRY_DATE_EDEFAULT.equals(expiryDate);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (type: ");
		result.append(type);
		result.append(", name: ");
		result.append(name);
		result.append(", price: ");
		result.append(price);
		result.append(", manufactoringDate: ");
		result.append(manufactoringDate);
		result.append(", expiryDate: ");
		result.append(expiryDate);
		result.append(')');
		return result.toString();
	}

} //DrugImpl
