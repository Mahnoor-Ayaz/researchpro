/**
 */
package research2.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import research2.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Research2FactoryImpl extends EFactoryImpl implements Research2Factory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Research2Factory init() {
		try {
			Research2Factory theResearch2Factory = (Research2Factory) EPackage.Registry.INSTANCE
					.getEFactory(Research2Package.eNS_URI);
			if (theResearch2Factory != null) {
				return theResearch2Factory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new Research2FactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Research2FactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case Research2Package.EPRESCRIPTION:
			return createEPrescription();
		case Research2Package.PATIENT:
			return createPatient();
		case Research2Package.DIESEASE:
			return createDiesease();
		case Research2Package.DRUG:
			return createDrug();
		case Research2Package.CLASSIFIER:
			return createClassifier();
		case Research2Package.DECISION_TREE:
			return createDecisionTree();
		case Research2Package.NEURAL_NETWORK:
			return createNeuralNetwork();
		case Research2Package.PRESCRIPTION:
			return createPrescription();
		case Research2Package.RANDOM_FOREST:
			return createRandomForest();
		case Research2Package.STOCK:
			return createStock();
		case Research2Package.PHARMACIST:
			return createPharmacist();
		case Research2Package.DOCTOR:
			return createDoctor();
		case Research2Package.HISTORY:
			return createHistory();
		case Research2Package.RECOMMENDATION_SYSTEM:
			return createRecommendationSystem();
		case Research2Package.FEATURE_EXTRACTION:
			return createFeatureExtraction();
		case Research2Package.PREDICTION:
			return createPrediction();
		case Research2Package.LIST:
			return createList();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case Research2Package.DRUG_TYPE:
			return createDrugTypeFromString(eDataType, initialValue);
		case Research2Package.SEVERITY:
			return createSeverityFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case Research2Package.DRUG_TYPE:
			return convertDrugTypeToString(eDataType, instanceValue);
		case Research2Package.SEVERITY:
			return convertSeverityToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EPrescription createEPrescription() {
		EPrescriptionImpl ePrescription = new EPrescriptionImpl();
		return ePrescription;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Patient createPatient() {
		PatientImpl patient = new PatientImpl();
		return patient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Diesease createDiesease() {
		DieseaseImpl diesease = new DieseaseImpl();
		return diesease;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Drug createDrug() {
		DrugImpl drug = new DrugImpl();
		return drug;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Classifier createClassifier() {
		ClassifierImpl classifier = new ClassifierImpl();
		return classifier;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DecisionTree createDecisionTree() {
		DecisionTreeImpl decisionTree = new DecisionTreeImpl();
		return decisionTree;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NeuralNetwork createNeuralNetwork() {
		NeuralNetworkImpl neuralNetwork = new NeuralNetworkImpl();
		return neuralNetwork;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Prescription createPrescription() {
		PrescriptionImpl prescription = new PrescriptionImpl();
		return prescription;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RandomForest createRandomForest() {
		RandomForestImpl randomForest = new RandomForestImpl();
		return randomForest;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stock createStock() {
		StockImpl stock = new StockImpl();
		return stock;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Pharmacist createPharmacist() {
		PharmacistImpl pharmacist = new PharmacistImpl();
		return pharmacist;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Doctor createDoctor() {
		DoctorImpl doctor = new DoctorImpl();
		return doctor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public History createHistory() {
		HistoryImpl history = new HistoryImpl();
		return history;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RecommendationSystem createRecommendationSystem() {
		RecommendationSystemImpl recommendationSystem = new RecommendationSystemImpl();
		return recommendationSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FeatureExtraction createFeatureExtraction() {
		FeatureExtractionImpl featureExtraction = new FeatureExtractionImpl();
		return featureExtraction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Prediction createPrediction() {
		PredictionImpl prediction = new PredictionImpl();
		return prediction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List createList() {
		ListImpl list = new ListImpl();
		return list;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DrugType createDrugTypeFromString(EDataType eDataType, String initialValue) {
		DrugType result = DrugType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertDrugTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Severity createSeverityFromString(EDataType eDataType, String initialValue) {
		Severity result = Severity.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertSeverityToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Research2Package getResearch2Package() {
		return (Research2Package) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static Research2Package getPackage() {
		return Research2Package.eINSTANCE;
	}

} //Research2FactoryImpl
