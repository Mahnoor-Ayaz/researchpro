/**
 */
package research2.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import research2.Doctor;
import research2.Drug;
import research2.Patient;
import research2.Prescription;
import research2.Research2Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Prescription</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link research2.impl.PrescriptionImpl#getHavedrug <em>Havedrug</em>}</li>
 *   <li>{@link research2.impl.PrescriptionImpl#getPatient <em>Patient</em>}</li>
 *   <li>{@link research2.impl.PrescriptionImpl#getPdoctor <em>Pdoctor</em>}</li>
 *   <li>{@link research2.impl.PrescriptionImpl#getQuantity <em>Quantity</em>}</li>
 *   <li>{@link research2.impl.PrescriptionImpl#getPrescriptionId <em>Prescription Id</em>}</li>
 *   <li>{@link research2.impl.PrescriptionImpl#getDrugname <em>Drugname</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PrescriptionImpl extends MinimalEObjectImpl.Container implements Prescription {
	/**
	 * The cached value of the '{@link #getHavedrug() <em>Havedrug</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHavedrug()
	 * @generated
	 * @ordered
	 */
	protected EList<Drug> havedrug;

	/**
	 * The cached value of the '{@link #getPatient() <em>Patient</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPatient()
	 * @generated
	 * @ordered
	 */
	protected Patient patient;

	/**
	 * The cached value of the '{@link #getPdoctor() <em>Pdoctor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPdoctor()
	 * @generated
	 * @ordered
	 */
	protected Doctor pdoctor;

	/**
	 * The default value of the '{@link #getQuantity() <em>Quantity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQuantity()
	 * @generated
	 * @ordered
	 */
	protected static final int QUANTITY_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getQuantity() <em>Quantity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQuantity()
	 * @generated
	 * @ordered
	 */
	protected int quantity = QUANTITY_EDEFAULT;

	/**
	 * The default value of the '{@link #getPrescriptionId() <em>Prescription Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrescriptionId()
	 * @generated
	 * @ordered
	 */
	protected static final int PRESCRIPTION_ID_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getPrescriptionId() <em>Prescription Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrescriptionId()
	 * @generated
	 * @ordered
	 */
	protected int prescriptionId = PRESCRIPTION_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getDrugname() <em>Drugname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDrugname()
	 * @generated
	 * @ordered
	 */
	protected static final String DRUGNAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDrugname() <em>Drugname</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDrugname()
	 * @generated
	 * @ordered
	 */
	protected String drugname = DRUGNAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PrescriptionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Research2Package.Literals.PRESCRIPTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Drug> getHavedrug() {
		if (havedrug == null) {
			havedrug = new EObjectResolvingEList<Drug>(Drug.class, this, Research2Package.PRESCRIPTION__HAVEDRUG);
		}
		return havedrug;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Patient getPatient() {
		if (patient != null && patient.eIsProxy()) {
			InternalEObject oldPatient = (InternalEObject) patient;
			patient = (Patient) eResolveProxy(oldPatient);
			if (patient != oldPatient) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Research2Package.PRESCRIPTION__PATIENT,
							oldPatient, patient));
			}
		}
		return patient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Patient basicGetPatient() {
		return patient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPatient(Patient newPatient, NotificationChain msgs) {
		Patient oldPatient = patient;
		patient = newPatient;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Research2Package.PRESCRIPTION__PATIENT, oldPatient, newPatient);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPatient(Patient newPatient) {
		if (newPatient != patient) {
			NotificationChain msgs = null;
			if (patient != null)
				msgs = ((InternalEObject) patient).eInverseRemove(this, Research2Package.PATIENT__GETPRESCRIPTION,
						Patient.class, msgs);
			if (newPatient != null)
				msgs = ((InternalEObject) newPatient).eInverseAdd(this, Research2Package.PATIENT__GETPRESCRIPTION,
						Patient.class, msgs);
			msgs = basicSetPatient(newPatient, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.PRESCRIPTION__PATIENT, newPatient,
					newPatient));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Doctor getPdoctor() {
		if (pdoctor != null && pdoctor.eIsProxy()) {
			InternalEObject oldPdoctor = (InternalEObject) pdoctor;
			pdoctor = (Doctor) eResolveProxy(oldPdoctor);
			if (pdoctor != oldPdoctor) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Research2Package.PRESCRIPTION__PDOCTOR,
							oldPdoctor, pdoctor));
			}
		}
		return pdoctor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Doctor basicGetPdoctor() {
		return pdoctor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPdoctor(Doctor newPdoctor, NotificationChain msgs) {
		Doctor oldPdoctor = pdoctor;
		pdoctor = newPdoctor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Research2Package.PRESCRIPTION__PDOCTOR, oldPdoctor, newPdoctor);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPdoctor(Doctor newPdoctor) {
		if (newPdoctor != pdoctor) {
			NotificationChain msgs = null;
			if (pdoctor != null)
				msgs = ((InternalEObject) pdoctor).eInverseRemove(this, Research2Package.DOCTOR__DPRESCRIPTION,
						Doctor.class, msgs);
			if (newPdoctor != null)
				msgs = ((InternalEObject) newPdoctor).eInverseAdd(this, Research2Package.DOCTOR__DPRESCRIPTION,
						Doctor.class, msgs);
			msgs = basicSetPdoctor(newPdoctor, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.PRESCRIPTION__PDOCTOR, newPdoctor,
					newPdoctor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setQuantity(int newQuantity) {
		int oldQuantity = quantity;
		quantity = newQuantity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.PRESCRIPTION__QUANTITY, oldQuantity,
					quantity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getPrescriptionId() {
		return prescriptionId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrescriptionId(int newPrescriptionId) {
		int oldPrescriptionId = prescriptionId;
		prescriptionId = newPrescriptionId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.PRESCRIPTION__PRESCRIPTION_ID,
					oldPrescriptionId, prescriptionId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDrugname() {
		return drugname;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDrugname(String newDrugname) {
		String oldDrugname = drugname;
		drugname = newDrugname;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Research2Package.PRESCRIPTION__DRUGNAME, oldDrugname,
					drugname));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Research2Package.PRESCRIPTION__PATIENT:
			if (patient != null)
				msgs = ((InternalEObject) patient).eInverseRemove(this, Research2Package.PATIENT__GETPRESCRIPTION,
						Patient.class, msgs);
			return basicSetPatient((Patient) otherEnd, msgs);
		case Research2Package.PRESCRIPTION__PDOCTOR:
			if (pdoctor != null)
				msgs = ((InternalEObject) pdoctor).eInverseRemove(this, Research2Package.DOCTOR__DPRESCRIPTION,
						Doctor.class, msgs);
			return basicSetPdoctor((Doctor) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Research2Package.PRESCRIPTION__PATIENT:
			return basicSetPatient(null, msgs);
		case Research2Package.PRESCRIPTION__PDOCTOR:
			return basicSetPdoctor(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Research2Package.PRESCRIPTION__HAVEDRUG:
			return getHavedrug();
		case Research2Package.PRESCRIPTION__PATIENT:
			if (resolve)
				return getPatient();
			return basicGetPatient();
		case Research2Package.PRESCRIPTION__PDOCTOR:
			if (resolve)
				return getPdoctor();
			return basicGetPdoctor();
		case Research2Package.PRESCRIPTION__QUANTITY:
			return getQuantity();
		case Research2Package.PRESCRIPTION__PRESCRIPTION_ID:
			return getPrescriptionId();
		case Research2Package.PRESCRIPTION__DRUGNAME:
			return getDrugname();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Research2Package.PRESCRIPTION__HAVEDRUG:
			getHavedrug().clear();
			getHavedrug().addAll((Collection<? extends Drug>) newValue);
			return;
		case Research2Package.PRESCRIPTION__PATIENT:
			setPatient((Patient) newValue);
			return;
		case Research2Package.PRESCRIPTION__PDOCTOR:
			setPdoctor((Doctor) newValue);
			return;
		case Research2Package.PRESCRIPTION__QUANTITY:
			setQuantity((Integer) newValue);
			return;
		case Research2Package.PRESCRIPTION__PRESCRIPTION_ID:
			setPrescriptionId((Integer) newValue);
			return;
		case Research2Package.PRESCRIPTION__DRUGNAME:
			setDrugname((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Research2Package.PRESCRIPTION__HAVEDRUG:
			getHavedrug().clear();
			return;
		case Research2Package.PRESCRIPTION__PATIENT:
			setPatient((Patient) null);
			return;
		case Research2Package.PRESCRIPTION__PDOCTOR:
			setPdoctor((Doctor) null);
			return;
		case Research2Package.PRESCRIPTION__QUANTITY:
			setQuantity(QUANTITY_EDEFAULT);
			return;
		case Research2Package.PRESCRIPTION__PRESCRIPTION_ID:
			setPrescriptionId(PRESCRIPTION_ID_EDEFAULT);
			return;
		case Research2Package.PRESCRIPTION__DRUGNAME:
			setDrugname(DRUGNAME_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Research2Package.PRESCRIPTION__HAVEDRUG:
			return havedrug != null && !havedrug.isEmpty();
		case Research2Package.PRESCRIPTION__PATIENT:
			return patient != null;
		case Research2Package.PRESCRIPTION__PDOCTOR:
			return pdoctor != null;
		case Research2Package.PRESCRIPTION__QUANTITY:
			return quantity != QUANTITY_EDEFAULT;
		case Research2Package.PRESCRIPTION__PRESCRIPTION_ID:
			return prescriptionId != PRESCRIPTION_ID_EDEFAULT;
		case Research2Package.PRESCRIPTION__DRUGNAME:
			return DRUGNAME_EDEFAULT == null ? drugname != null : !DRUGNAME_EDEFAULT.equals(drugname);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (quantity: ");
		result.append(quantity);
		result.append(", prescriptionId: ");
		result.append(prescriptionId);
		result.append(", drugname: ");
		result.append(drugname);
		result.append(')');
		return result.toString();
	}

} //PrescriptionImpl
