/**
 */
package research2;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see research2.Research2Factory
 * @model kind="package"
 * @generated
 */
public interface Research2Package extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "research2";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/research2";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "research2";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Research2Package eINSTANCE = research2.impl.Research2PackageImpl.init();

	/**
	 * The meta object id for the '{@link research2.impl.EPrescriptionImpl <em>EPrescription</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.EPrescriptionImpl
	 * @see research2.impl.Research2PackageImpl#getEPrescription()
	 * @generated
	 */
	int EPRESCRIPTION = 0;

	/**
	 * The feature id for the '<em><b>Patient</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EPRESCRIPTION__PATIENT = 0;

	/**
	 * The feature id for the '<em><b>Doctor</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EPRESCRIPTION__DOCTOR = 1;

	/**
	 * The feature id for the '<em><b>Prescription</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EPRESCRIPTION__PRESCRIPTION = 2;

	/**
	 * The feature id for the '<em><b>History</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EPRESCRIPTION__HISTORY = 3;

	/**
	 * The feature id for the '<em><b>Recommendationsystem</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EPRESCRIPTION__RECOMMENDATIONSYSTEM = 4;

	/**
	 * The feature id for the '<em><b>Pharmacist</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EPRESCRIPTION__PHARMACIST = 5;

	/**
	 * The feature id for the '<em><b>Stock</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EPRESCRIPTION__STOCK = 6;

	/**
	 * The feature id for the '<em><b>Classifier</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EPRESCRIPTION__CLASSIFIER = 7;

	/**
	 * The feature id for the '<em><b>Prediction</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EPRESCRIPTION__PREDICTION = 8;

	/**
	 * The feature id for the '<em><b>List</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EPRESCRIPTION__LIST = 9;

	/**
	 * The feature id for the '<em><b>Diesease</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EPRESCRIPTION__DIESEASE = 10;

	/**
	 * The feature id for the '<em><b>Drug</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EPRESCRIPTION__DRUG = 11;

	/**
	 * The number of structural features of the '<em>EPrescription</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EPRESCRIPTION_FEATURE_COUNT = 12;

	/**
	 * The number of operations of the '<em>EPrescription</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EPRESCRIPTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link research2.impl.PatientImpl <em>Patient</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.PatientImpl
	 * @see research2.impl.Research2PackageImpl#getPatient()
	 * @generated
	 */
	int PATIENT = 1;

	/**
	 * The feature id for the '<em><b>History</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__HISTORY = 0;

	/**
	 * The feature id for the '<em><b>Getprescription</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__GETPRESCRIPTION = 1;

	/**
	 * The feature id for the '<em><b>Havedoctor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__HAVEDOCTOR = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__NAME = 3;

	/**
	 * The feature id for the '<em><b>Patient Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__PATIENT_ID = 4;

	/**
	 * The feature id for the '<em><b>Age</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__AGE = 5;

	/**
	 * The number of structural features of the '<em>Patient</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Patient</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link research2.impl.DieseaseImpl <em>Diesease</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.DieseaseImpl
	 * @see research2.impl.Research2PackageImpl#getDiesease()
	 * @generated
	 */
	int DIESEASE = 2;

	/**
	 * The feature id for the '<em><b>Ofdrug</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIESEASE__OFDRUG = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIESEASE__NAME = 1;

	/**
	 * The feature id for the '<em><b>Severity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIESEASE__SEVERITY = 2;

	/**
	 * The number of structural features of the '<em>Diesease</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIESEASE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Diesease</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DIESEASE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link research2.impl.DrugImpl <em>Drug</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.DrugImpl
	 * @see research2.impl.Research2PackageImpl#getDrug()
	 * @generated
	 */
	int DRUG = 3;

	/**
	 * The feature id for the '<em><b>Ofdiesease</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRUG__OFDIESEASE = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRUG__TYPE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRUG__NAME = 2;

	/**
	 * The feature id for the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRUG__PRICE = 3;

	/**
	 * The feature id for the '<em><b>Manufactoring Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRUG__MANUFACTORING_DATE = 4;

	/**
	 * The feature id for the '<em><b>Expiry Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRUG__EXPIRY_DATE = 5;

	/**
	 * The number of structural features of the '<em>Drug</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRUG_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Drug</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRUG_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link research2.impl.ClassifierImpl <em>Classifier</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.ClassifierImpl
	 * @see research2.impl.Research2PackageImpl#getClassifier()
	 * @generated
	 */
	int CLASSIFIER = 4;

	/**
	 * The feature id for the '<em><b>Prediction</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASSIFIER__PREDICTION = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASSIFIER__NAME = 1;

	/**
	 * The feature id for the '<em><b>Dataset</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASSIFIER__DATASET = 2;

	/**
	 * The feature id for the '<em><b>Featureextraction</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASSIFIER__FEATUREEXTRACTION = 3;

	/**
	 * The feature id for the '<em><b>Model</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASSIFIER__MODEL = 4;

	/**
	 * The number of structural features of the '<em>Classifier</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASSIFIER_FEATURE_COUNT = 5;

	/**
	 * The operation id for the '<em>Classify</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASSIFIER___CLASSIFY = 0;

	/**
	 * The number of operations of the '<em>Classifier</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASSIFIER_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link research2.impl.ModelImpl <em>Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.ModelImpl
	 * @see research2.impl.Research2PackageImpl#getModel()
	 * @generated
	 */
	int MODEL = 6;

	/**
	 * The number of structural features of the '<em>Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MODEL_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MODEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link research2.impl.DecisionTreeImpl <em>Decision Tree</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.DecisionTreeImpl
	 * @see research2.impl.Research2PackageImpl#getDecisionTree()
	 * @generated
	 */
	int DECISION_TREE = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_TREE__NAME = MODEL_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Decision Tree</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_TREE_FEATURE_COUNT = MODEL_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Trainningdata</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_TREE___TRAINNINGDATA = MODEL_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Testingdata</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_TREE___TESTINGDATA = MODEL_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Predict</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_TREE___PREDICT = MODEL_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Recall</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_TREE___RECALL = MODEL_OPERATION_COUNT + 3;

	/**
	 * The number of operations of the '<em>Decision Tree</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DECISION_TREE_OPERATION_COUNT = MODEL_OPERATION_COUNT + 4;

	/**
	 * The meta object id for the '{@link research2.impl.NeuralNetworkImpl <em>Neural Network</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.NeuralNetworkImpl
	 * @see research2.impl.Research2PackageImpl#getNeuralNetwork()
	 * @generated
	 */
	int NEURAL_NETWORK = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEURAL_NETWORK__NAME = MODEL_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Neural Network</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEURAL_NETWORK_FEATURE_COUNT = MODEL_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Trainingdats</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEURAL_NETWORK___TRAININGDATS = MODEL_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Testingdata</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEURAL_NETWORK___TESTINGDATA = MODEL_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Predict</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEURAL_NETWORK___PREDICT = MODEL_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Recall</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEURAL_NETWORK___RECALL = MODEL_OPERATION_COUNT + 3;

	/**
	 * The number of operations of the '<em>Neural Network</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEURAL_NETWORK_OPERATION_COUNT = MODEL_OPERATION_COUNT + 4;

	/**
	 * The meta object id for the '{@link research2.impl.PrescriptionImpl <em>Prescription</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.PrescriptionImpl
	 * @see research2.impl.Research2PackageImpl#getPrescription()
	 * @generated
	 */
	int PRESCRIPTION = 8;

	/**
	 * The feature id for the '<em><b>Havedrug</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESCRIPTION__HAVEDRUG = 0;

	/**
	 * The feature id for the '<em><b>Patient</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESCRIPTION__PATIENT = 1;

	/**
	 * The feature id for the '<em><b>Pdoctor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESCRIPTION__PDOCTOR = 2;

	/**
	 * The feature id for the '<em><b>Quantity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESCRIPTION__QUANTITY = 3;

	/**
	 * The feature id for the '<em><b>Prescription Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESCRIPTION__PRESCRIPTION_ID = 4;

	/**
	 * The feature id for the '<em><b>Drugname</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESCRIPTION__DRUGNAME = 5;

	/**
	 * The number of structural features of the '<em>Prescription</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESCRIPTION_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Prescription</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRESCRIPTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link research2.impl.RandomForestImpl <em>Random Forest</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.RandomForestImpl
	 * @see research2.impl.Research2PackageImpl#getRandomForest()
	 * @generated
	 */
	int RANDOM_FOREST = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RANDOM_FOREST__NAME = MODEL_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Random Forest</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RANDOM_FOREST_FEATURE_COUNT = MODEL_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Trainingdata</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RANDOM_FOREST___TRAININGDATA = MODEL_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Testingdata</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RANDOM_FOREST___TESTINGDATA = MODEL_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Predict</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RANDOM_FOREST___PREDICT = MODEL_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Recall</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RANDOM_FOREST___RECALL = MODEL_OPERATION_COUNT + 3;

	/**
	 * The number of operations of the '<em>Random Forest</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RANDOM_FOREST_OPERATION_COUNT = MODEL_OPERATION_COUNT + 4;

	/**
	 * The meta object id for the '{@link research2.impl.StockImpl <em>Stock</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.StockImpl
	 * @see research2.impl.Research2PackageImpl#getStock()
	 * @generated
	 */
	int STOCK = 10;

	/**
	 * The feature id for the '<em><b>Drugs</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOCK__DRUGS = 0;

	/**
	 * The number of structural features of the '<em>Stock</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOCK_FEATURE_COUNT = 1;

	/**
	 * The operation id for the '<em>Checkavailability</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOCK___CHECKAVAILABILITY = 0;

	/**
	 * The number of operations of the '<em>Stock</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOCK_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link research2.impl.PharmacistImpl <em>Pharmacist</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.PharmacistImpl
	 * @see research2.impl.Research2PackageImpl#getPharmacist()
	 * @generated
	 */
	int PHARMACIST = 11;

	/**
	 * The feature id for the '<em><b>Get</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACIST__GET = 0;

	/**
	 * The feature id for the '<em><b>Checkstock</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACIST__CHECKSTOCK = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACIST__NAME = 2;

	/**
	 * The feature id for the '<em><b>Pharmacit Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACIST__PHARMACIT_ID = 3;

	/**
	 * The number of structural features of the '<em>Pharmacist</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACIST_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Pharmacist</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACIST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link research2.impl.DoctorImpl <em>Doctor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.DoctorImpl
	 * @see research2.impl.Research2PackageImpl#getDoctor()
	 * @generated
	 */
	int DOCTOR = 12;

	/**
	 * The feature id for the '<em><b>Havepatient</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTOR__HAVEPATIENT = 0;

	/**
	 * The feature id for the '<em><b>Dprescription</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTOR__DPRESCRIPTION = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTOR__NAME = 2;

	/**
	 * The feature id for the '<em><b>Doctor Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTOR__DOCTOR_ID = 3;

	/**
	 * The number of structural features of the '<em>Doctor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTOR_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Doctor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link research2.impl.HistoryImpl <em>History</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.HistoryImpl
	 * @see research2.impl.Research2PackageImpl#getHistory()
	 * @generated
	 */
	int HISTORY = 13;

	/**
	 * The feature id for the '<em><b>Patient</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY__PATIENT = 0;

	/**
	 * The feature id for the '<em><b>Containdiesease</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY__CONTAINDIESEASE = 1;

	/**
	 * The feature id for the '<em><b>Containdrug</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY__CONTAINDRUG = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY__NAME = 3;

	/**
	 * The number of structural features of the '<em>History</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY_FEATURE_COUNT = 4;

	/**
	 * The operation id for the '<em>View</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY___VIEW = 0;

	/**
	 * The operation id for the '<em>Modify</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY___MODIFY = 1;

	/**
	 * The number of operations of the '<em>History</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY_OPERATION_COUNT = 2;

	/**
	 * The meta object id for the '{@link research2.impl.RecommendationSystemImpl <em>Recommendation System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.RecommendationSystemImpl
	 * @see research2.impl.Research2PackageImpl#getRecommendationSystem()
	 * @generated
	 */
	int RECOMMENDATION_SYSTEM = 14;

	/**
	 * The feature id for the '<em><b>Classifier</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECOMMENDATION_SYSTEM__CLASSIFIER = 0;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECOMMENDATION_SYSTEM__TITLE = 1;

	/**
	 * The feature id for the '<em><b>List</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECOMMENDATION_SYSTEM__LIST = 2;

	/**
	 * The number of structural features of the '<em>Recommendation System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECOMMENDATION_SYSTEM_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Recommendation System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RECOMMENDATION_SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link research2.impl.FeatureExtractionImpl <em>Feature Extraction</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.FeatureExtractionImpl
	 * @see research2.impl.Research2PackageImpl#getFeatureExtraction()
	 * @generated
	 */
	int FEATURE_EXTRACTION = 15;

	/**
	 * The feature id for the '<em><b>Feature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_EXTRACTION__FEATURE = 0;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_EXTRACTION__LABEL = 1;

	/**
	 * The feature id for the '<em><b>History</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_EXTRACTION__HISTORY = 2;

	/**
	 * The number of structural features of the '<em>Feature Extraction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_EXTRACTION_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Extract</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_EXTRACTION___EXTRACT = 0;

	/**
	 * The number of operations of the '<em>Feature Extraction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_EXTRACTION_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link research2.impl.PredictionImpl <em>Prediction</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.PredictionImpl
	 * @see research2.impl.Research2PackageImpl#getPrediction()
	 * @generated
	 */
	int PREDICTION = 16;

	/**
	 * The feature id for the '<em><b>Predicted Drug</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREDICTION__PREDICTED_DRUG = 0;

	/**
	 * The feature id for the '<em><b>List</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREDICTION__LIST = 1;

	/**
	 * The number of structural features of the '<em>Prediction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREDICTION_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Prediction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREDICTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link research2.impl.ListImpl <em>List</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.impl.ListImpl
	 * @see research2.impl.Research2PackageImpl#getList()
	 * @generated
	 */
	int LIST = 17;

	/**
	 * The feature id for the '<em><b>Goesto</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST__GOESTO = 0;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST__TITLE = 1;

	/**
	 * The number of structural features of the '<em>List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link research2.DrugType <em>Drug Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.DrugType
	 * @see research2.impl.Research2PackageImpl#getDrugType()
	 * @generated
	 */
	int DRUG_TYPE = 18;

	/**
	 * The meta object id for the '{@link research2.Severity <em>Severity</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research2.Severity
	 * @see research2.impl.Research2PackageImpl#getSeverity()
	 * @generated
	 */
	int SEVERITY = 19;

	/**
	 * Returns the meta object for class '{@link research2.EPrescription <em>EPrescription</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>EPrescription</em>'.
	 * @see research2.EPrescription
	 * @generated
	 */
	EClass getEPrescription();

	/**
	 * Returns the meta object for the containment reference list '{@link research2.EPrescription#getPatient <em>Patient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Patient</em>'.
	 * @see research2.EPrescription#getPatient()
	 * @see #getEPrescription()
	 * @generated
	 */
	EReference getEPrescription_Patient();

	/**
	 * Returns the meta object for the containment reference list '{@link research2.EPrescription#getDoctor <em>Doctor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Doctor</em>'.
	 * @see research2.EPrescription#getDoctor()
	 * @see #getEPrescription()
	 * @generated
	 */
	EReference getEPrescription_Doctor();

	/**
	 * Returns the meta object for the containment reference list '{@link research2.EPrescription#getPrescription <em>Prescription</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Prescription</em>'.
	 * @see research2.EPrescription#getPrescription()
	 * @see #getEPrescription()
	 * @generated
	 */
	EReference getEPrescription_Prescription();

	/**
	 * Returns the meta object for the containment reference list '{@link research2.EPrescription#getHistory <em>History</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>History</em>'.
	 * @see research2.EPrescription#getHistory()
	 * @see #getEPrescription()
	 * @generated
	 */
	EReference getEPrescription_History();

	/**
	 * Returns the meta object for the containment reference list '{@link research2.EPrescription#getRecommendationsystem <em>Recommendationsystem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Recommendationsystem</em>'.
	 * @see research2.EPrescription#getRecommendationsystem()
	 * @see #getEPrescription()
	 * @generated
	 */
	EReference getEPrescription_Recommendationsystem();

	/**
	 * Returns the meta object for the containment reference list '{@link research2.EPrescription#getPharmacist <em>Pharmacist</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Pharmacist</em>'.
	 * @see research2.EPrescription#getPharmacist()
	 * @see #getEPrescription()
	 * @generated
	 */
	EReference getEPrescription_Pharmacist();

	/**
	 * Returns the meta object for the containment reference list '{@link research2.EPrescription#getStock <em>Stock</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Stock</em>'.
	 * @see research2.EPrescription#getStock()
	 * @see #getEPrescription()
	 * @generated
	 */
	EReference getEPrescription_Stock();

	/**
	 * Returns the meta object for the containment reference list '{@link research2.EPrescription#getClassifier <em>Classifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Classifier</em>'.
	 * @see research2.EPrescription#getClassifier()
	 * @see #getEPrescription()
	 * @generated
	 */
	EReference getEPrescription_Classifier();

	/**
	 * Returns the meta object for the containment reference list '{@link research2.EPrescription#getPrediction <em>Prediction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Prediction</em>'.
	 * @see research2.EPrescription#getPrediction()
	 * @see #getEPrescription()
	 * @generated
	 */
	EReference getEPrescription_Prediction();

	/**
	 * Returns the meta object for the containment reference list '{@link research2.EPrescription#getList <em>List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>List</em>'.
	 * @see research2.EPrescription#getList()
	 * @see #getEPrescription()
	 * @generated
	 */
	EReference getEPrescription_List();

	/**
	 * Returns the meta object for the containment reference list '{@link research2.EPrescription#getDiesease <em>Diesease</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Diesease</em>'.
	 * @see research2.EPrescription#getDiesease()
	 * @see #getEPrescription()
	 * @generated
	 */
	EReference getEPrescription_Diesease();

	/**
	 * Returns the meta object for the containment reference list '{@link research2.EPrescription#getDrug <em>Drug</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Drug</em>'.
	 * @see research2.EPrescription#getDrug()
	 * @see #getEPrescription()
	 * @generated
	 */
	EReference getEPrescription_Drug();

	/**
	 * Returns the meta object for class '{@link research2.Patient <em>Patient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Patient</em>'.
	 * @see research2.Patient
	 * @generated
	 */
	EClass getPatient();

	/**
	 * Returns the meta object for the reference list '{@link research2.Patient#getHistory <em>History</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>History</em>'.
	 * @see research2.Patient#getHistory()
	 * @see #getPatient()
	 * @generated
	 */
	EReference getPatient_History();

	/**
	 * Returns the meta object for the reference list '{@link research2.Patient#getGetprescription <em>Getprescription</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Getprescription</em>'.
	 * @see research2.Patient#getGetprescription()
	 * @see #getPatient()
	 * @generated
	 */
	EReference getPatient_Getprescription();

	/**
	 * Returns the meta object for the reference '{@link research2.Patient#getHavedoctor <em>Havedoctor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Havedoctor</em>'.
	 * @see research2.Patient#getHavedoctor()
	 * @see #getPatient()
	 * @generated
	 */
	EReference getPatient_Havedoctor();

	/**
	 * Returns the meta object for the attribute '{@link research2.Patient#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see research2.Patient#getName()
	 * @see #getPatient()
	 * @generated
	 */
	EAttribute getPatient_Name();

	/**
	 * Returns the meta object for the attribute '{@link research2.Patient#getPatientId <em>Patient Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Patient Id</em>'.
	 * @see research2.Patient#getPatientId()
	 * @see #getPatient()
	 * @generated
	 */
	EAttribute getPatient_PatientId();

	/**
	 * Returns the meta object for the attribute '{@link research2.Patient#getAge <em>Age</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Age</em>'.
	 * @see research2.Patient#getAge()
	 * @see #getPatient()
	 * @generated
	 */
	EAttribute getPatient_Age();

	/**
	 * Returns the meta object for class '{@link research2.Diesease <em>Diesease</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Diesease</em>'.
	 * @see research2.Diesease
	 * @generated
	 */
	EClass getDiesease();

	/**
	 * Returns the meta object for the reference list '{@link research2.Diesease#getOfdrug <em>Ofdrug</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Ofdrug</em>'.
	 * @see research2.Diesease#getOfdrug()
	 * @see #getDiesease()
	 * @generated
	 */
	EReference getDiesease_Ofdrug();

	/**
	 * Returns the meta object for the attribute '{@link research2.Diesease#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see research2.Diesease#getName()
	 * @see #getDiesease()
	 * @generated
	 */
	EAttribute getDiesease_Name();

	/**
	 * Returns the meta object for the attribute '{@link research2.Diesease#getSeverity <em>Severity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Severity</em>'.
	 * @see research2.Diesease#getSeverity()
	 * @see #getDiesease()
	 * @generated
	 */
	EAttribute getDiesease_Severity();

	/**
	 * Returns the meta object for class '{@link research2.Drug <em>Drug</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Drug</em>'.
	 * @see research2.Drug
	 * @generated
	 */
	EClass getDrug();

	/**
	 * Returns the meta object for the reference list '{@link research2.Drug#getOfdiesease <em>Ofdiesease</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Ofdiesease</em>'.
	 * @see research2.Drug#getOfdiesease()
	 * @see #getDrug()
	 * @generated
	 */
	EReference getDrug_Ofdiesease();

	/**
	 * Returns the meta object for the attribute '{@link research2.Drug#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see research2.Drug#getType()
	 * @see #getDrug()
	 * @generated
	 */
	EAttribute getDrug_Type();

	/**
	 * Returns the meta object for the attribute '{@link research2.Drug#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see research2.Drug#getName()
	 * @see #getDrug()
	 * @generated
	 */
	EAttribute getDrug_Name();

	/**
	 * Returns the meta object for the attribute '{@link research2.Drug#getPrice <em>Price</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Price</em>'.
	 * @see research2.Drug#getPrice()
	 * @see #getDrug()
	 * @generated
	 */
	EAttribute getDrug_Price();

	/**
	 * Returns the meta object for the attribute '{@link research2.Drug#getManufactoringDate <em>Manufactoring Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Manufactoring Date</em>'.
	 * @see research2.Drug#getManufactoringDate()
	 * @see #getDrug()
	 * @generated
	 */
	EAttribute getDrug_ManufactoringDate();

	/**
	 * Returns the meta object for the attribute '{@link research2.Drug#getExpiryDate <em>Expiry Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Expiry Date</em>'.
	 * @see research2.Drug#getExpiryDate()
	 * @see #getDrug()
	 * @generated
	 */
	EAttribute getDrug_ExpiryDate();

	/**
	 * Returns the meta object for class '{@link research2.Classifier <em>Classifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Classifier</em>'.
	 * @see research2.Classifier
	 * @generated
	 */
	EClass getClassifier();

	/**
	 * Returns the meta object for the reference '{@link research2.Classifier#getPrediction <em>Prediction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Prediction</em>'.
	 * @see research2.Classifier#getPrediction()
	 * @see #getClassifier()
	 * @generated
	 */
	EReference getClassifier_Prediction();

	/**
	 * Returns the meta object for the attribute '{@link research2.Classifier#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see research2.Classifier#getName()
	 * @see #getClassifier()
	 * @generated
	 */
	EAttribute getClassifier_Name();

	/**
	 * Returns the meta object for the attribute '{@link research2.Classifier#getDataset <em>Dataset</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dataset</em>'.
	 * @see research2.Classifier#getDataset()
	 * @see #getClassifier()
	 * @generated
	 */
	EAttribute getClassifier_Dataset();

	/**
	 * Returns the meta object for the containment reference list '{@link research2.Classifier#getFeatureextraction <em>Featureextraction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Featureextraction</em>'.
	 * @see research2.Classifier#getFeatureextraction()
	 * @see #getClassifier()
	 * @generated
	 */
	EReference getClassifier_Featureextraction();

	/**
	 * Returns the meta object for the containment reference list '{@link research2.Classifier#getModel <em>Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Model</em>'.
	 * @see research2.Classifier#getModel()
	 * @see #getClassifier()
	 * @generated
	 */
	EReference getClassifier_Model();

	/**
	 * Returns the meta object for the '{@link research2.Classifier#classify() <em>Classify</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Classify</em>' operation.
	 * @see research2.Classifier#classify()
	 * @generated
	 */
	EOperation getClassifier__Classify();

	/**
	 * Returns the meta object for class '{@link research2.DecisionTree <em>Decision Tree</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Decision Tree</em>'.
	 * @see research2.DecisionTree
	 * @generated
	 */
	EClass getDecisionTree();

	/**
	 * Returns the meta object for the attribute '{@link research2.DecisionTree#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see research2.DecisionTree#getName()
	 * @see #getDecisionTree()
	 * @generated
	 */
	EAttribute getDecisionTree_Name();

	/**
	 * Returns the meta object for the '{@link research2.DecisionTree#trainningdata() <em>Trainningdata</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Trainningdata</em>' operation.
	 * @see research2.DecisionTree#trainningdata()
	 * @generated
	 */
	EOperation getDecisionTree__Trainningdata();

	/**
	 * Returns the meta object for the '{@link research2.DecisionTree#testingdata() <em>Testingdata</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Testingdata</em>' operation.
	 * @see research2.DecisionTree#testingdata()
	 * @generated
	 */
	EOperation getDecisionTree__Testingdata();

	/**
	 * Returns the meta object for the '{@link research2.DecisionTree#predict() <em>Predict</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Predict</em>' operation.
	 * @see research2.DecisionTree#predict()
	 * @generated
	 */
	EOperation getDecisionTree__Predict();

	/**
	 * Returns the meta object for the '{@link research2.DecisionTree#recall() <em>Recall</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Recall</em>' operation.
	 * @see research2.DecisionTree#recall()
	 * @generated
	 */
	EOperation getDecisionTree__Recall();

	/**
	 * Returns the meta object for class '{@link research2.Model <em>Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Model</em>'.
	 * @see research2.Model
	 * @generated
	 */
	EClass getModel();

	/**
	 * Returns the meta object for class '{@link research2.NeuralNetwork <em>Neural Network</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Neural Network</em>'.
	 * @see research2.NeuralNetwork
	 * @generated
	 */
	EClass getNeuralNetwork();

	/**
	 * Returns the meta object for the attribute '{@link research2.NeuralNetwork#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see research2.NeuralNetwork#getName()
	 * @see #getNeuralNetwork()
	 * @generated
	 */
	EAttribute getNeuralNetwork_Name();

	/**
	 * Returns the meta object for the '{@link research2.NeuralNetwork#trainingdats() <em>Trainingdats</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Trainingdats</em>' operation.
	 * @see research2.NeuralNetwork#trainingdats()
	 * @generated
	 */
	EOperation getNeuralNetwork__Trainingdats();

	/**
	 * Returns the meta object for the '{@link research2.NeuralNetwork#testingdata() <em>Testingdata</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Testingdata</em>' operation.
	 * @see research2.NeuralNetwork#testingdata()
	 * @generated
	 */
	EOperation getNeuralNetwork__Testingdata();

	/**
	 * Returns the meta object for the '{@link research2.NeuralNetwork#predict() <em>Predict</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Predict</em>' operation.
	 * @see research2.NeuralNetwork#predict()
	 * @generated
	 */
	EOperation getNeuralNetwork__Predict();

	/**
	 * Returns the meta object for the '{@link research2.NeuralNetwork#recall() <em>Recall</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Recall</em>' operation.
	 * @see research2.NeuralNetwork#recall()
	 * @generated
	 */
	EOperation getNeuralNetwork__Recall();

	/**
	 * Returns the meta object for class '{@link research2.Prescription <em>Prescription</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Prescription</em>'.
	 * @see research2.Prescription
	 * @generated
	 */
	EClass getPrescription();

	/**
	 * Returns the meta object for the reference list '{@link research2.Prescription#getHavedrug <em>Havedrug</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Havedrug</em>'.
	 * @see research2.Prescription#getHavedrug()
	 * @see #getPrescription()
	 * @generated
	 */
	EReference getPrescription_Havedrug();

	/**
	 * Returns the meta object for the reference '{@link research2.Prescription#getPatient <em>Patient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Patient</em>'.
	 * @see research2.Prescription#getPatient()
	 * @see #getPrescription()
	 * @generated
	 */
	EReference getPrescription_Patient();

	/**
	 * Returns the meta object for the reference '{@link research2.Prescription#getPdoctor <em>Pdoctor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Pdoctor</em>'.
	 * @see research2.Prescription#getPdoctor()
	 * @see #getPrescription()
	 * @generated
	 */
	EReference getPrescription_Pdoctor();

	/**
	 * Returns the meta object for the attribute '{@link research2.Prescription#getQuantity <em>Quantity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Quantity</em>'.
	 * @see research2.Prescription#getQuantity()
	 * @see #getPrescription()
	 * @generated
	 */
	EAttribute getPrescription_Quantity();

	/**
	 * Returns the meta object for the attribute '{@link research2.Prescription#getPrescriptionId <em>Prescription Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Prescription Id</em>'.
	 * @see research2.Prescription#getPrescriptionId()
	 * @see #getPrescription()
	 * @generated
	 */
	EAttribute getPrescription_PrescriptionId();

	/**
	 * Returns the meta object for the attribute '{@link research2.Prescription#getDrugname <em>Drugname</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Drugname</em>'.
	 * @see research2.Prescription#getDrugname()
	 * @see #getPrescription()
	 * @generated
	 */
	EAttribute getPrescription_Drugname();

	/**
	 * Returns the meta object for class '{@link research2.RandomForest <em>Random Forest</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Random Forest</em>'.
	 * @see research2.RandomForest
	 * @generated
	 */
	EClass getRandomForest();

	/**
	 * Returns the meta object for the attribute '{@link research2.RandomForest#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see research2.RandomForest#getName()
	 * @see #getRandomForest()
	 * @generated
	 */
	EAttribute getRandomForest_Name();

	/**
	 * Returns the meta object for the '{@link research2.RandomForest#trainingdata() <em>Trainingdata</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Trainingdata</em>' operation.
	 * @see research2.RandomForest#trainingdata()
	 * @generated
	 */
	EOperation getRandomForest__Trainingdata();

	/**
	 * Returns the meta object for the '{@link research2.RandomForest#testingdata() <em>Testingdata</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Testingdata</em>' operation.
	 * @see research2.RandomForest#testingdata()
	 * @generated
	 */
	EOperation getRandomForest__Testingdata();

	/**
	 * Returns the meta object for the '{@link research2.RandomForest#predict() <em>Predict</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Predict</em>' operation.
	 * @see research2.RandomForest#predict()
	 * @generated
	 */
	EOperation getRandomForest__Predict();

	/**
	 * Returns the meta object for the '{@link research2.RandomForest#recall() <em>Recall</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Recall</em>' operation.
	 * @see research2.RandomForest#recall()
	 * @generated
	 */
	EOperation getRandomForest__Recall();

	/**
	 * Returns the meta object for class '{@link research2.Stock <em>Stock</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Stock</em>'.
	 * @see research2.Stock
	 * @generated
	 */
	EClass getStock();

	/**
	 * Returns the meta object for the attribute '{@link research2.Stock#getDrugs <em>Drugs</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Drugs</em>'.
	 * @see research2.Stock#getDrugs()
	 * @see #getStock()
	 * @generated
	 */
	EAttribute getStock_Drugs();

	/**
	 * Returns the meta object for the '{@link research2.Stock#checkavailability() <em>Checkavailability</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Checkavailability</em>' operation.
	 * @see research2.Stock#checkavailability()
	 * @generated
	 */
	EOperation getStock__Checkavailability();

	/**
	 * Returns the meta object for class '{@link research2.Pharmacist <em>Pharmacist</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pharmacist</em>'.
	 * @see research2.Pharmacist
	 * @generated
	 */
	EClass getPharmacist();

	/**
	 * Returns the meta object for the reference list '{@link research2.Pharmacist#getGet <em>Get</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Get</em>'.
	 * @see research2.Pharmacist#getGet()
	 * @see #getPharmacist()
	 * @generated
	 */
	EReference getPharmacist_Get();

	/**
	 * Returns the meta object for the reference list '{@link research2.Pharmacist#getCheckstock <em>Checkstock</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Checkstock</em>'.
	 * @see research2.Pharmacist#getCheckstock()
	 * @see #getPharmacist()
	 * @generated
	 */
	EReference getPharmacist_Checkstock();

	/**
	 * Returns the meta object for the attribute '{@link research2.Pharmacist#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see research2.Pharmacist#getName()
	 * @see #getPharmacist()
	 * @generated
	 */
	EAttribute getPharmacist_Name();

	/**
	 * Returns the meta object for the attribute '{@link research2.Pharmacist#getPharmacitId <em>Pharmacit Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Pharmacit Id</em>'.
	 * @see research2.Pharmacist#getPharmacitId()
	 * @see #getPharmacist()
	 * @generated
	 */
	EAttribute getPharmacist_PharmacitId();

	/**
	 * Returns the meta object for class '{@link research2.Doctor <em>Doctor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Doctor</em>'.
	 * @see research2.Doctor
	 * @generated
	 */
	EClass getDoctor();

	/**
	 * Returns the meta object for the reference list '{@link research2.Doctor#getHavepatient <em>Havepatient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Havepatient</em>'.
	 * @see research2.Doctor#getHavepatient()
	 * @see #getDoctor()
	 * @generated
	 */
	EReference getDoctor_Havepatient();

	/**
	 * Returns the meta object for the reference list '{@link research2.Doctor#getDprescription <em>Dprescription</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Dprescription</em>'.
	 * @see research2.Doctor#getDprescription()
	 * @see #getDoctor()
	 * @generated
	 */
	EReference getDoctor_Dprescription();

	/**
	 * Returns the meta object for the attribute '{@link research2.Doctor#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see research2.Doctor#getName()
	 * @see #getDoctor()
	 * @generated
	 */
	EAttribute getDoctor_Name();

	/**
	 * Returns the meta object for the attribute '{@link research2.Doctor#getDoctorId <em>Doctor Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Doctor Id</em>'.
	 * @see research2.Doctor#getDoctorId()
	 * @see #getDoctor()
	 * @generated
	 */
	EAttribute getDoctor_DoctorId();

	/**
	 * Returns the meta object for class '{@link research2.History <em>History</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>History</em>'.
	 * @see research2.History
	 * @generated
	 */
	EClass getHistory();

	/**
	 * Returns the meta object for the reference '{@link research2.History#getPatient <em>Patient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Patient</em>'.
	 * @see research2.History#getPatient()
	 * @see #getHistory()
	 * @generated
	 */
	EReference getHistory_Patient();

	/**
	 * Returns the meta object for the reference list '{@link research2.History#getContaindiesease <em>Containdiesease</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Containdiesease</em>'.
	 * @see research2.History#getContaindiesease()
	 * @see #getHistory()
	 * @generated
	 */
	EReference getHistory_Containdiesease();

	/**
	 * Returns the meta object for the reference list '{@link research2.History#getContaindrug <em>Containdrug</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Containdrug</em>'.
	 * @see research2.History#getContaindrug()
	 * @see #getHistory()
	 * @generated
	 */
	EReference getHistory_Containdrug();

	/**
	 * Returns the meta object for the attribute '{@link research2.History#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see research2.History#getName()
	 * @see #getHistory()
	 * @generated
	 */
	EAttribute getHistory_Name();

	/**
	 * Returns the meta object for the '{@link research2.History#view() <em>View</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>View</em>' operation.
	 * @see research2.History#view()
	 * @generated
	 */
	EOperation getHistory__View();

	/**
	 * Returns the meta object for the '{@link research2.History#modify() <em>Modify</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Modify</em>' operation.
	 * @see research2.History#modify()
	 * @generated
	 */
	EOperation getHistory__Modify();

	/**
	 * Returns the meta object for class '{@link research2.RecommendationSystem <em>Recommendation System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Recommendation System</em>'.
	 * @see research2.RecommendationSystem
	 * @generated
	 */
	EClass getRecommendationSystem();

	/**
	 * Returns the meta object for the reference '{@link research2.RecommendationSystem#getClassifier <em>Classifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Classifier</em>'.
	 * @see research2.RecommendationSystem#getClassifier()
	 * @see #getRecommendationSystem()
	 * @generated
	 */
	EReference getRecommendationSystem_Classifier();

	/**
	 * Returns the meta object for the attribute '{@link research2.RecommendationSystem#getTitle <em>Title</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Title</em>'.
	 * @see research2.RecommendationSystem#getTitle()
	 * @see #getRecommendationSystem()
	 * @generated
	 */
	EAttribute getRecommendationSystem_Title();

	/**
	 * Returns the meta object for the reference '{@link research2.RecommendationSystem#getList <em>List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>List</em>'.
	 * @see research2.RecommendationSystem#getList()
	 * @see #getRecommendationSystem()
	 * @generated
	 */
	EReference getRecommendationSystem_List();

	/**
	 * Returns the meta object for class '{@link research2.FeatureExtraction <em>Feature Extraction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Feature Extraction</em>'.
	 * @see research2.FeatureExtraction
	 * @generated
	 */
	EClass getFeatureExtraction();

	/**
	 * Returns the meta object for the attribute '{@link research2.FeatureExtraction#getFeature <em>Feature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Feature</em>'.
	 * @see research2.FeatureExtraction#getFeature()
	 * @see #getFeatureExtraction()
	 * @generated
	 */
	EAttribute getFeatureExtraction_Feature();

	/**
	 * Returns the meta object for the attribute '{@link research2.FeatureExtraction#getLabel <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Label</em>'.
	 * @see research2.FeatureExtraction#getLabel()
	 * @see #getFeatureExtraction()
	 * @generated
	 */
	EAttribute getFeatureExtraction_Label();

	/**
	 * Returns the meta object for the reference '{@link research2.FeatureExtraction#getHistory <em>History</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>History</em>'.
	 * @see research2.FeatureExtraction#getHistory()
	 * @see #getFeatureExtraction()
	 * @generated
	 */
	EReference getFeatureExtraction_History();

	/**
	 * Returns the meta object for the '{@link research2.FeatureExtraction#extract() <em>Extract</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Extract</em>' operation.
	 * @see research2.FeatureExtraction#extract()
	 * @generated
	 */
	EOperation getFeatureExtraction__Extract();

	/**
	 * Returns the meta object for class '{@link research2.Prediction <em>Prediction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Prediction</em>'.
	 * @see research2.Prediction
	 * @generated
	 */
	EClass getPrediction();

	/**
	 * Returns the meta object for the attribute '{@link research2.Prediction#getPredictedDrug <em>Predicted Drug</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Predicted Drug</em>'.
	 * @see research2.Prediction#getPredictedDrug()
	 * @see #getPrediction()
	 * @generated
	 */
	EAttribute getPrediction_PredictedDrug();

	/**
	 * Returns the meta object for the reference '{@link research2.Prediction#getList <em>List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>List</em>'.
	 * @see research2.Prediction#getList()
	 * @see #getPrediction()
	 * @generated
	 */
	EReference getPrediction_List();

	/**
	 * Returns the meta object for class '{@link research2.List <em>List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>List</em>'.
	 * @see research2.List
	 * @generated
	 */
	EClass getList();

	/**
	 * Returns the meta object for the reference '{@link research2.List#getGoesto <em>Goesto</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Goesto</em>'.
	 * @see research2.List#getGoesto()
	 * @see #getList()
	 * @generated
	 */
	EReference getList_Goesto();

	/**
	 * Returns the meta object for the attribute '{@link research2.List#getTitle <em>Title</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Title</em>'.
	 * @see research2.List#getTitle()
	 * @see #getList()
	 * @generated
	 */
	EAttribute getList_Title();

	/**
	 * Returns the meta object for enum '{@link research2.DrugType <em>Drug Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Drug Type</em>'.
	 * @see research2.DrugType
	 * @generated
	 */
	EEnum getDrugType();

	/**
	 * Returns the meta object for enum '{@link research2.Severity <em>Severity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Severity</em>'.
	 * @see research2.Severity
	 * @generated
	 */
	EEnum getSeverity();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	Research2Factory getResearch2Factory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link research2.impl.EPrescriptionImpl <em>EPrescription</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.EPrescriptionImpl
		 * @see research2.impl.Research2PackageImpl#getEPrescription()
		 * @generated
		 */
		EClass EPRESCRIPTION = eINSTANCE.getEPrescription();

		/**
		 * The meta object literal for the '<em><b>Patient</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EPRESCRIPTION__PATIENT = eINSTANCE.getEPrescription_Patient();

		/**
		 * The meta object literal for the '<em><b>Doctor</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EPRESCRIPTION__DOCTOR = eINSTANCE.getEPrescription_Doctor();

		/**
		 * The meta object literal for the '<em><b>Prescription</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EPRESCRIPTION__PRESCRIPTION = eINSTANCE.getEPrescription_Prescription();

		/**
		 * The meta object literal for the '<em><b>History</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EPRESCRIPTION__HISTORY = eINSTANCE.getEPrescription_History();

		/**
		 * The meta object literal for the '<em><b>Recommendationsystem</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EPRESCRIPTION__RECOMMENDATIONSYSTEM = eINSTANCE.getEPrescription_Recommendationsystem();

		/**
		 * The meta object literal for the '<em><b>Pharmacist</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EPRESCRIPTION__PHARMACIST = eINSTANCE.getEPrescription_Pharmacist();

		/**
		 * The meta object literal for the '<em><b>Stock</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EPRESCRIPTION__STOCK = eINSTANCE.getEPrescription_Stock();

		/**
		 * The meta object literal for the '<em><b>Classifier</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EPRESCRIPTION__CLASSIFIER = eINSTANCE.getEPrescription_Classifier();

		/**
		 * The meta object literal for the '<em><b>Prediction</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EPRESCRIPTION__PREDICTION = eINSTANCE.getEPrescription_Prediction();

		/**
		 * The meta object literal for the '<em><b>List</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EPRESCRIPTION__LIST = eINSTANCE.getEPrescription_List();

		/**
		 * The meta object literal for the '<em><b>Diesease</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EPRESCRIPTION__DIESEASE = eINSTANCE.getEPrescription_Diesease();

		/**
		 * The meta object literal for the '<em><b>Drug</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EPRESCRIPTION__DRUG = eINSTANCE.getEPrescription_Drug();

		/**
		 * The meta object literal for the '{@link research2.impl.PatientImpl <em>Patient</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.PatientImpl
		 * @see research2.impl.Research2PackageImpl#getPatient()
		 * @generated
		 */
		EClass PATIENT = eINSTANCE.getPatient();

		/**
		 * The meta object literal for the '<em><b>History</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENT__HISTORY = eINSTANCE.getPatient_History();

		/**
		 * The meta object literal for the '<em><b>Getprescription</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENT__GETPRESCRIPTION = eINSTANCE.getPatient_Getprescription();

		/**
		 * The meta object literal for the '<em><b>Havedoctor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENT__HAVEDOCTOR = eINSTANCE.getPatient_Havedoctor();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PATIENT__NAME = eINSTANCE.getPatient_Name();

		/**
		 * The meta object literal for the '<em><b>Patient Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PATIENT__PATIENT_ID = eINSTANCE.getPatient_PatientId();

		/**
		 * The meta object literal for the '<em><b>Age</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PATIENT__AGE = eINSTANCE.getPatient_Age();

		/**
		 * The meta object literal for the '{@link research2.impl.DieseaseImpl <em>Diesease</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.DieseaseImpl
		 * @see research2.impl.Research2PackageImpl#getDiesease()
		 * @generated
		 */
		EClass DIESEASE = eINSTANCE.getDiesease();

		/**
		 * The meta object literal for the '<em><b>Ofdrug</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DIESEASE__OFDRUG = eINSTANCE.getDiesease_Ofdrug();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIESEASE__NAME = eINSTANCE.getDiesease_Name();

		/**
		 * The meta object literal for the '<em><b>Severity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DIESEASE__SEVERITY = eINSTANCE.getDiesease_Severity();

		/**
		 * The meta object literal for the '{@link research2.impl.DrugImpl <em>Drug</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.DrugImpl
		 * @see research2.impl.Research2PackageImpl#getDrug()
		 * @generated
		 */
		EClass DRUG = eINSTANCE.getDrug();

		/**
		 * The meta object literal for the '<em><b>Ofdiesease</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DRUG__OFDIESEASE = eINSTANCE.getDrug_Ofdiesease();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DRUG__TYPE = eINSTANCE.getDrug_Type();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DRUG__NAME = eINSTANCE.getDrug_Name();

		/**
		 * The meta object literal for the '<em><b>Price</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DRUG__PRICE = eINSTANCE.getDrug_Price();

		/**
		 * The meta object literal for the '<em><b>Manufactoring Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DRUG__MANUFACTORING_DATE = eINSTANCE.getDrug_ManufactoringDate();

		/**
		 * The meta object literal for the '<em><b>Expiry Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DRUG__EXPIRY_DATE = eINSTANCE.getDrug_ExpiryDate();

		/**
		 * The meta object literal for the '{@link research2.impl.ClassifierImpl <em>Classifier</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.ClassifierImpl
		 * @see research2.impl.Research2PackageImpl#getClassifier()
		 * @generated
		 */
		EClass CLASSIFIER = eINSTANCE.getClassifier();

		/**
		 * The meta object literal for the '<em><b>Prediction</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLASSIFIER__PREDICTION = eINSTANCE.getClassifier_Prediction();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLASSIFIER__NAME = eINSTANCE.getClassifier_Name();

		/**
		 * The meta object literal for the '<em><b>Dataset</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLASSIFIER__DATASET = eINSTANCE.getClassifier_Dataset();

		/**
		 * The meta object literal for the '<em><b>Featureextraction</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLASSIFIER__FEATUREEXTRACTION = eINSTANCE.getClassifier_Featureextraction();

		/**
		 * The meta object literal for the '<em><b>Model</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLASSIFIER__MODEL = eINSTANCE.getClassifier_Model();

		/**
		 * The meta object literal for the '<em><b>Classify</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CLASSIFIER___CLASSIFY = eINSTANCE.getClassifier__Classify();

		/**
		 * The meta object literal for the '{@link research2.impl.DecisionTreeImpl <em>Decision Tree</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.DecisionTreeImpl
		 * @see research2.impl.Research2PackageImpl#getDecisionTree()
		 * @generated
		 */
		EClass DECISION_TREE = eINSTANCE.getDecisionTree();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DECISION_TREE__NAME = eINSTANCE.getDecisionTree_Name();

		/**
		 * The meta object literal for the '<em><b>Trainningdata</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DECISION_TREE___TRAINNINGDATA = eINSTANCE.getDecisionTree__Trainningdata();

		/**
		 * The meta object literal for the '<em><b>Testingdata</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DECISION_TREE___TESTINGDATA = eINSTANCE.getDecisionTree__Testingdata();

		/**
		 * The meta object literal for the '<em><b>Predict</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DECISION_TREE___PREDICT = eINSTANCE.getDecisionTree__Predict();

		/**
		 * The meta object literal for the '<em><b>Recall</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DECISION_TREE___RECALL = eINSTANCE.getDecisionTree__Recall();

		/**
		 * The meta object literal for the '{@link research2.impl.ModelImpl <em>Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.ModelImpl
		 * @see research2.impl.Research2PackageImpl#getModel()
		 * @generated
		 */
		EClass MODEL = eINSTANCE.getModel();

		/**
		 * The meta object literal for the '{@link research2.impl.NeuralNetworkImpl <em>Neural Network</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.NeuralNetworkImpl
		 * @see research2.impl.Research2PackageImpl#getNeuralNetwork()
		 * @generated
		 */
		EClass NEURAL_NETWORK = eINSTANCE.getNeuralNetwork();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NEURAL_NETWORK__NAME = eINSTANCE.getNeuralNetwork_Name();

		/**
		 * The meta object literal for the '<em><b>Trainingdats</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation NEURAL_NETWORK___TRAININGDATS = eINSTANCE.getNeuralNetwork__Trainingdats();

		/**
		 * The meta object literal for the '<em><b>Testingdata</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation NEURAL_NETWORK___TESTINGDATA = eINSTANCE.getNeuralNetwork__Testingdata();

		/**
		 * The meta object literal for the '<em><b>Predict</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation NEURAL_NETWORK___PREDICT = eINSTANCE.getNeuralNetwork__Predict();

		/**
		 * The meta object literal for the '<em><b>Recall</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation NEURAL_NETWORK___RECALL = eINSTANCE.getNeuralNetwork__Recall();

		/**
		 * The meta object literal for the '{@link research2.impl.PrescriptionImpl <em>Prescription</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.PrescriptionImpl
		 * @see research2.impl.Research2PackageImpl#getPrescription()
		 * @generated
		 */
		EClass PRESCRIPTION = eINSTANCE.getPrescription();

		/**
		 * The meta object literal for the '<em><b>Havedrug</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRESCRIPTION__HAVEDRUG = eINSTANCE.getPrescription_Havedrug();

		/**
		 * The meta object literal for the '<em><b>Patient</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRESCRIPTION__PATIENT = eINSTANCE.getPrescription_Patient();

		/**
		 * The meta object literal for the '<em><b>Pdoctor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRESCRIPTION__PDOCTOR = eINSTANCE.getPrescription_Pdoctor();

		/**
		 * The meta object literal for the '<em><b>Quantity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRESCRIPTION__QUANTITY = eINSTANCE.getPrescription_Quantity();

		/**
		 * The meta object literal for the '<em><b>Prescription Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRESCRIPTION__PRESCRIPTION_ID = eINSTANCE.getPrescription_PrescriptionId();

		/**
		 * The meta object literal for the '<em><b>Drugname</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRESCRIPTION__DRUGNAME = eINSTANCE.getPrescription_Drugname();

		/**
		 * The meta object literal for the '{@link research2.impl.RandomForestImpl <em>Random Forest</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.RandomForestImpl
		 * @see research2.impl.Research2PackageImpl#getRandomForest()
		 * @generated
		 */
		EClass RANDOM_FOREST = eINSTANCE.getRandomForest();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RANDOM_FOREST__NAME = eINSTANCE.getRandomForest_Name();

		/**
		 * The meta object literal for the '<em><b>Trainingdata</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation RANDOM_FOREST___TRAININGDATA = eINSTANCE.getRandomForest__Trainingdata();

		/**
		 * The meta object literal for the '<em><b>Testingdata</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation RANDOM_FOREST___TESTINGDATA = eINSTANCE.getRandomForest__Testingdata();

		/**
		 * The meta object literal for the '<em><b>Predict</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation RANDOM_FOREST___PREDICT = eINSTANCE.getRandomForest__Predict();

		/**
		 * The meta object literal for the '<em><b>Recall</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation RANDOM_FOREST___RECALL = eINSTANCE.getRandomForest__Recall();

		/**
		 * The meta object literal for the '{@link research2.impl.StockImpl <em>Stock</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.StockImpl
		 * @see research2.impl.Research2PackageImpl#getStock()
		 * @generated
		 */
		EClass STOCK = eINSTANCE.getStock();

		/**
		 * The meta object literal for the '<em><b>Drugs</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOCK__DRUGS = eINSTANCE.getStock_Drugs();

		/**
		 * The meta object literal for the '<em><b>Checkavailability</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STOCK___CHECKAVAILABILITY = eINSTANCE.getStock__Checkavailability();

		/**
		 * The meta object literal for the '{@link research2.impl.PharmacistImpl <em>Pharmacist</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.PharmacistImpl
		 * @see research2.impl.Research2PackageImpl#getPharmacist()
		 * @generated
		 */
		EClass PHARMACIST = eINSTANCE.getPharmacist();

		/**
		 * The meta object literal for the '<em><b>Get</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHARMACIST__GET = eINSTANCE.getPharmacist_Get();

		/**
		 * The meta object literal for the '<em><b>Checkstock</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHARMACIST__CHECKSTOCK = eINSTANCE.getPharmacist_Checkstock();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHARMACIST__NAME = eINSTANCE.getPharmacist_Name();

		/**
		 * The meta object literal for the '<em><b>Pharmacit Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHARMACIST__PHARMACIT_ID = eINSTANCE.getPharmacist_PharmacitId();

		/**
		 * The meta object literal for the '{@link research2.impl.DoctorImpl <em>Doctor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.DoctorImpl
		 * @see research2.impl.Research2PackageImpl#getDoctor()
		 * @generated
		 */
		EClass DOCTOR = eINSTANCE.getDoctor();

		/**
		 * The meta object literal for the '<em><b>Havepatient</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCTOR__HAVEPATIENT = eINSTANCE.getDoctor_Havepatient();

		/**
		 * The meta object literal for the '<em><b>Dprescription</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCTOR__DPRESCRIPTION = eINSTANCE.getDoctor_Dprescription();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCTOR__NAME = eINSTANCE.getDoctor_Name();

		/**
		 * The meta object literal for the '<em><b>Doctor Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCTOR__DOCTOR_ID = eINSTANCE.getDoctor_DoctorId();

		/**
		 * The meta object literal for the '{@link research2.impl.HistoryImpl <em>History</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.HistoryImpl
		 * @see research2.impl.Research2PackageImpl#getHistory()
		 * @generated
		 */
		EClass HISTORY = eINSTANCE.getHistory();

		/**
		 * The meta object literal for the '<em><b>Patient</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HISTORY__PATIENT = eINSTANCE.getHistory_Patient();

		/**
		 * The meta object literal for the '<em><b>Containdiesease</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HISTORY__CONTAINDIESEASE = eINSTANCE.getHistory_Containdiesease();

		/**
		 * The meta object literal for the '<em><b>Containdrug</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HISTORY__CONTAINDRUG = eINSTANCE.getHistory_Containdrug();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HISTORY__NAME = eINSTANCE.getHistory_Name();

		/**
		 * The meta object literal for the '<em><b>View</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation HISTORY___VIEW = eINSTANCE.getHistory__View();

		/**
		 * The meta object literal for the '<em><b>Modify</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation HISTORY___MODIFY = eINSTANCE.getHistory__Modify();

		/**
		 * The meta object literal for the '{@link research2.impl.RecommendationSystemImpl <em>Recommendation System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.RecommendationSystemImpl
		 * @see research2.impl.Research2PackageImpl#getRecommendationSystem()
		 * @generated
		 */
		EClass RECOMMENDATION_SYSTEM = eINSTANCE.getRecommendationSystem();

		/**
		 * The meta object literal for the '<em><b>Classifier</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RECOMMENDATION_SYSTEM__CLASSIFIER = eINSTANCE.getRecommendationSystem_Classifier();

		/**
		 * The meta object literal for the '<em><b>Title</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RECOMMENDATION_SYSTEM__TITLE = eINSTANCE.getRecommendationSystem_Title();

		/**
		 * The meta object literal for the '<em><b>List</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RECOMMENDATION_SYSTEM__LIST = eINSTANCE.getRecommendationSystem_List();

		/**
		 * The meta object literal for the '{@link research2.impl.FeatureExtractionImpl <em>Feature Extraction</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.FeatureExtractionImpl
		 * @see research2.impl.Research2PackageImpl#getFeatureExtraction()
		 * @generated
		 */
		EClass FEATURE_EXTRACTION = eINSTANCE.getFeatureExtraction();

		/**
		 * The meta object literal for the '<em><b>Feature</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FEATURE_EXTRACTION__FEATURE = eINSTANCE.getFeatureExtraction_Feature();

		/**
		 * The meta object literal for the '<em><b>Label</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FEATURE_EXTRACTION__LABEL = eINSTANCE.getFeatureExtraction_Label();

		/**
		 * The meta object literal for the '<em><b>History</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEATURE_EXTRACTION__HISTORY = eINSTANCE.getFeatureExtraction_History();

		/**
		 * The meta object literal for the '<em><b>Extract</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FEATURE_EXTRACTION___EXTRACT = eINSTANCE.getFeatureExtraction__Extract();

		/**
		 * The meta object literal for the '{@link research2.impl.PredictionImpl <em>Prediction</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.PredictionImpl
		 * @see research2.impl.Research2PackageImpl#getPrediction()
		 * @generated
		 */
		EClass PREDICTION = eINSTANCE.getPrediction();

		/**
		 * The meta object literal for the '<em><b>Predicted Drug</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PREDICTION__PREDICTED_DRUG = eINSTANCE.getPrediction_PredictedDrug();

		/**
		 * The meta object literal for the '<em><b>List</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PREDICTION__LIST = eINSTANCE.getPrediction_List();

		/**
		 * The meta object literal for the '{@link research2.impl.ListImpl <em>List</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.impl.ListImpl
		 * @see research2.impl.Research2PackageImpl#getList()
		 * @generated
		 */
		EClass LIST = eINSTANCE.getList();

		/**
		 * The meta object literal for the '<em><b>Goesto</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LIST__GOESTO = eINSTANCE.getList_Goesto();

		/**
		 * The meta object literal for the '<em><b>Title</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIST__TITLE = eINSTANCE.getList_Title();

		/**
		 * The meta object literal for the '{@link research2.DrugType <em>Drug Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.DrugType
		 * @see research2.impl.Research2PackageImpl#getDrugType()
		 * @generated
		 */
		EEnum DRUG_TYPE = eINSTANCE.getDrugType();

		/**
		 * The meta object literal for the '{@link research2.Severity <em>Severity</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research2.Severity
		 * @see research2.impl.Research2PackageImpl#getSeverity()
		 * @generated
		 */
		EEnum SEVERITY = eINSTANCE.getSeverity();

	}

} //Research2Package
