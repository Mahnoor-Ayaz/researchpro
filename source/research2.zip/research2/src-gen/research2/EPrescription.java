/**
 */
package research2;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EPrescription</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research2.EPrescription#getPatient <em>Patient</em>}</li>
 *   <li>{@link research2.EPrescription#getDoctor <em>Doctor</em>}</li>
 *   <li>{@link research2.EPrescription#getPrescription <em>Prescription</em>}</li>
 *   <li>{@link research2.EPrescription#getHistory <em>History</em>}</li>
 *   <li>{@link research2.EPrescription#getRecommendationsystem <em>Recommendationsystem</em>}</li>
 *   <li>{@link research2.EPrescription#getPharmacist <em>Pharmacist</em>}</li>
 *   <li>{@link research2.EPrescription#getStock <em>Stock</em>}</li>
 *   <li>{@link research2.EPrescription#getClassifier <em>Classifier</em>}</li>
 *   <li>{@link research2.EPrescription#getPrediction <em>Prediction</em>}</li>
 *   <li>{@link research2.EPrescription#getList <em>List</em>}</li>
 *   <li>{@link research2.EPrescription#getDiesease <em>Diesease</em>}</li>
 *   <li>{@link research2.EPrescription#getDrug <em>Drug</em>}</li>
 * </ul>
 *
 * @see research2.Research2Package#getEPrescription()
 * @model
 * @generated
 */
public interface EPrescription extends EObject {
	/**
	 * Returns the value of the '<em><b>Patient</b></em>' containment reference list.
	 * The list contents are of type {@link research2.Patient}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Patient</em>' containment reference list.
	 * @see research2.Research2Package#getEPrescription_Patient()
	 * @model containment="true"
	 * @generated
	 */
	EList<Patient> getPatient();

	/**
	 * Returns the value of the '<em><b>Doctor</b></em>' containment reference list.
	 * The list contents are of type {@link research2.Doctor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Doctor</em>' containment reference list.
	 * @see research2.Research2Package#getEPrescription_Doctor()
	 * @model containment="true"
	 * @generated
	 */
	EList<Doctor> getDoctor();

	/**
	 * Returns the value of the '<em><b>Prescription</b></em>' containment reference list.
	 * The list contents are of type {@link research2.Prescription}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Prescription</em>' containment reference list.
	 * @see research2.Research2Package#getEPrescription_Prescription()
	 * @model containment="true"
	 * @generated
	 */
	EList<Prescription> getPrescription();

	/**
	 * Returns the value of the '<em><b>History</b></em>' containment reference list.
	 * The list contents are of type {@link research2.History}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>History</em>' containment reference list.
	 * @see research2.Research2Package#getEPrescription_History()
	 * @model containment="true"
	 * @generated
	 */
	EList<History> getHistory();

	/**
	 * Returns the value of the '<em><b>Recommendationsystem</b></em>' containment reference list.
	 * The list contents are of type {@link research2.RecommendationSystem}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Recommendationsystem</em>' containment reference list.
	 * @see research2.Research2Package#getEPrescription_Recommendationsystem()
	 * @model containment="true"
	 * @generated
	 */
	EList<RecommendationSystem> getRecommendationsystem();

	/**
	 * Returns the value of the '<em><b>Pharmacist</b></em>' containment reference list.
	 * The list contents are of type {@link research2.Pharmacist}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pharmacist</em>' containment reference list.
	 * @see research2.Research2Package#getEPrescription_Pharmacist()
	 * @model containment="true"
	 * @generated
	 */
	EList<Pharmacist> getPharmacist();

	/**
	 * Returns the value of the '<em><b>Stock</b></em>' containment reference list.
	 * The list contents are of type {@link research2.Stock}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stock</em>' containment reference list.
	 * @see research2.Research2Package#getEPrescription_Stock()
	 * @model containment="true"
	 * @generated
	 */
	EList<Stock> getStock();

	/**
	 * Returns the value of the '<em><b>Classifier</b></em>' containment reference list.
	 * The list contents are of type {@link research2.Classifier}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Classifier</em>' containment reference list.
	 * @see research2.Research2Package#getEPrescription_Classifier()
	 * @model containment="true"
	 * @generated
	 */
	EList<Classifier> getClassifier();

	/**
	 * Returns the value of the '<em><b>Prediction</b></em>' containment reference list.
	 * The list contents are of type {@link research2.Prediction}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Prediction</em>' containment reference list.
	 * @see research2.Research2Package#getEPrescription_Prediction()
	 * @model containment="true"
	 * @generated
	 */
	EList<Prediction> getPrediction();

	/**
	 * Returns the value of the '<em><b>List</b></em>' containment reference list.
	 * The list contents are of type {@link research2.List}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>List</em>' containment reference list.
	 * @see research2.Research2Package#getEPrescription_List()
	 * @model containment="true"
	 * @generated
	 */
	EList<List> getList();

	/**
	 * Returns the value of the '<em><b>Diesease</b></em>' containment reference list.
	 * The list contents are of type {@link research2.Diesease}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Diesease</em>' containment reference list.
	 * @see research2.Research2Package#getEPrescription_Diesease()
	 * @model containment="true"
	 * @generated
	 */
	EList<Diesease> getDiesease();

	/**
	 * Returns the value of the '<em><b>Drug</b></em>' containment reference list.
	 * The list contents are of type {@link research2.Drug}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Drug</em>' containment reference list.
	 * @see research2.Research2Package#getEPrescription_Drug()
	 * @model containment="true"
	 * @generated
	 */
	EList<Drug> getDrug();

} // EPrescription
